;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="2032c509-52ef-dd1e-36f2-4967e03fec17")}catch(e){}}();
(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,992122,e=>{e.v({coverContainer:"ReplIcon-module__P34J6a__coverContainer",imageBorder:"ReplIcon-module__P34J6a__imageBorder",imageWrapper:"ReplIcon-module__P34J6a__imageWrapper",loadingContainer:"ReplIcon-module__P34J6a__loadingContainer",loadingIconWrapper:"ReplIcon-module__P34J6a__loadingIconWrapper",loadingOverlay:"ReplIcon-module__P34J6a__loadingOverlay",surface:"ReplIcon-module__P34J6a__surface"})},595996,e=>{"use strict";var t=e.i(276385),n=e.i(389959),o=e.i(983420),r=e.i(919073),a=e.i(61732),s=e.i(727223),i=e.i(992122);let l={16:4,20:4,24:4,32:4,36:4,48:4,64:8,84:16};function c(e){let c=(0,n.useContext)(o.IconContext),{size:u=c.size??32,alt:d=c.alt??"",iconUrl:g}=e,p=u<32?4:8;function C(){return(0,t.jsx)(a.View,{clsx:i.default.imageBorder,style:{borderRadius:p}})}if(g.endsWith(".svg")){let e=l[u],n=u-2*e;return(0,t.jsxs)(r.ShadesSurface,{clsx:i.default.surface,p:e,br:p,style:{width:u,height:u},children:[(0,t.jsx)(a.View,{clsx:i.default.imageWrapper,style:{width:n,height:n},children:(0,t.jsx)(s.default,{alt:d,src:g,objectFit:"contain",layout:"fill"})}),(0,t.jsx)(C,{})]})}return(0,t.jsxs)(r.ShadesSurface,{clsx:i.default.surface,br:p,style:{width:u,height:u},children:[(0,t.jsx)(s.default,{alt:d,src:g,width:u,height:u,objectFit:"cover"}),(0,t.jsx)(C,{})]})}e.s(["ReplIconWithPlaceholder",0,function({isLoading:e,alt:n,iconUrl:o,size:a=32}){let s=o&&void 0!==n?(0,t.jsx)(c,{alt:n,iconUrl:o,size:a}):null;if(!e&&s)return s;let l=a<32?4:8;return(0,t.jsx)(r.ShadesSurface,{clsx:i.default.surface,br:l,style:{width:a,height:a}})},"default",0,c])},305373,e=>{e.v({buttonGroup:"ButtonGroup-module__nrHH6q__buttonGroup",buttonGroupItem:"ButtonGroup-module__nrHH6q__buttonGroupItem",buttonGroupRow:"ButtonGroup-module__nrHH6q__buttonGroupRow",buttonGroupRowStretch:"ButtonGroup-module__nrHH6q__buttonGroupRowStretch",checked:"ButtonGroup-module__nrHH6q__checked"})},449525,e=>{"use strict";var t=e.i(276385),n=e.i(389959),o=e.i(330666),r=e.i(983420),a=e.i(546833),s=e.i(406664),i=e.i(379778),l=e.i(480028),c=e.i(919073),u=e.i(8047),d=e.i(61732),g=e.i(305373);let p=(0,l.cvarsFrom)("ButtonGroup.module.css",["--hover-background"]),C=(0,n.createContext)(null),m=d.SpecializedView.input;e.s(["ButtonGroup",0,function({name:e,value:n,row:o,stretch:r,disabled:a,onChange:s,children:i,primary:l,tag:u="fieldset",dataCy:d,...p}){let m=[g.default.buttonGroup,{[g.default.buttonGroupRow]:!!o,[g.default.buttonGroupRowStretch]:!!o&&!!r}];return(0,t.jsx)(c.ShadesSurface,{elevate:"1x",tag:u,...p,"data-cy":d,clsx:m,children:(0,t.jsx)(C.Provider,{value:{value:n,name:e,onChange:s,primary:l,disabled:a},children:i})})},"ButtonGroupItem",0,function({onChange:e,id:d,checked:f,disabled:h,name:O,value:y,text:S,icon:b,colorway:x,colorShade:_,dataCy:v,className:R,...E}){let A=(0,n.useContext)(C);A&&(O=O??A.name,f=f??A.value===y,e=e??A.onChange,h=h??A.disabled,x=x??(A.primary?"blue":void 0));let I=f?"filledAndOutlined":"nofill",w=(0,s.useCreateInteractive)({variant:I,colorway:f?x:void 0}),N=f?[]:a.shades.border("ghost"),U=(0,i.useView)({clsx:[...w.clsx,...N,g.default.buttonGroupItem,{[g.default.checked]:f}],className:R,style:{...w.style,...f&&{[p.hoverBackground]:x?l.colormap[x].dimmer:l.tokens.interactiveBackground}},grow:!0,row:!0,gap:8,px:8,justify:"center",align:"center"});return(0,t.jsxs)(c.ShadesSurface,{tag:"label",...U,"data-cy":v,"aria-disabled":h,colorShade:f?_:void 0,elevate:!1,children:[(0,t.jsx)(o.VisuallyHidden,{children:(0,t.jsx)(m,{id:d,name:O,value:y,type:"radio",checked:f,disabled:h,onChange:()=>e?.(y),...E})}),(0,t.jsx)(r.IconProvider,{size:16,children:b}),"string"==typeof S?(0,t.jsx)(u.Text,{multiline:!1,children:S}):S]})}])},790281,e=>{e.v({background:"Switch-module__C40utW__background",button:"Switch-module__C40utW__button",label:"Switch-module__C40utW__label",svg:"Switch-module__C40utW__svg"})},327391,e=>{"use strict";e.i(183940);var t=e.i(276385),n=e.i(389959),o=e.i(497953),r=e.i(99906),a=e.i(138715),s=e.i(104394),i=e.i(330666),l=e.i(480028),c=e.i(8047),u=e.i(61732),d=e.i(790281);let g=u.SpecializedView.label;e.s(["Switch",0,({colorway:e="primary",dataCy:u,size:p="default",fillColor:C,focusRingColor:m,...f})=>{let h=l.colormap[e],O=(0,n.useRef)(null),y=(0,o.useToggleState)(f),{inputProps:S}=function(e,t,n){let{labelProps:o,inputProps:r,isSelected:a,isPressed:i,isDisabled:l,isReadOnly:c}=(0,s.useToggle)(e,t,n);return{labelProps:o,inputProps:{...r,role:"switch",checked:a},isSelected:a,isPressed:i,isDisabled:l,isReadOnly:c}}(f,y,O),{focusProps:b,isFocusVisible:x}=(0,r.useFocusRing)(f),{hoverProps:_,isHovered:v}=(0,a.useHover)(f),{isSelected:R}=y,E=f.isDisabled||!1,A=f.isReadOnly||!1,I=n.Children.count(f.children)>0;void 0!==f["aria-label"]||f["aria-labelledby"];let w="small"===p,N=w?26:38,U=w?16:24,P=w?8:12,T=w?12:16,k=N-1,G=U-1,D=N+2,j=U+2,M=P+1,B=(0,t.jsxs)("svg",{"aria-hidden":"true",..._,width:N,height:U,viewBox:`0 0 ${N} ${U}`,fill:"none",xmlns:"http://www.w3.org/2000/svg",overflow:x?"visible":"hidden",style:{cursor:E||A?"auto":"pointer",opacity:E?.4:1},className:d.default.svg,children:[(0,t.jsx)("rect",{x:"0",y:"0",width:N,height:U,rx:P,fill:C??(R?E||A?h.dimmer:h.default:l.tokens.interactiveBorder),className:d.default.background}),(0,t.jsx)("rect",{x:R?w?12:18:w?2:4,y:w?2:4,width:T,height:T,rx:w?6:8,fill:l.tokens.white,className:d.default.button}),(0,t.jsx)("rect",{x:"0.5",y:"0.5",width:k,height:G,rx:P,stroke:!v||E||A?"transparent":R?h.strongest:l.tokens.interactiveBorderHover,"data-switch-outline":!0}),(0,t.jsx)("rect",{x:"-1",y:"-1",stroke:x?m??(R?h.strongest:h.default):"transparent",width:D,height:j,rx:M,strokeWidth:"2"})]});return I?(0,t.jsxs)(g,{clsx:d.default.label,"data-cy":u,children:[(0,t.jsx)(i.VisuallyHidden,{children:(0,t.jsx)("input",{...S,...b,ref:O})}),B,(0,t.jsx)(c.Text,{multiline:!1,variant:w?"small":"text",children:f.children})]}):(0,t.jsxs)(g,{clsx:d.default.label,"data-cy":u,children:[(0,t.jsx)(i.VisuallyHidden,{children:(0,t.jsx)("input",{...S,...b,ref:O})}),B]})}],327391)},151027,873054,672220,284693,e=>{"use strict";var t=e.i(276385),n=e.i(55547),o=e.i(389959),r=e.i(351623);let a=r.gql`
    fragment OrgFlagsOrg on Org {
  id
  flags {
    id
    type
    value
  }
}
    `;e.s(["OrgFlagsOrgFragmentDoc",0,a],873054);var s=e.i(344480);e.i(975473);var i=e.i(299020);let l={},c=r.gql`
    fragment CurrentUserOrg on Org {
  id
  slug
  currentUserRole
  dealContext {
    dealType
    salesContactEmail
  }
  ...OrgFlagsOrg
}
    ${a}`,u=r.gql`
    query CurrentUserOrgContext {
  getUserOrgContext2 {
    ... on Org {
      ...CurrentUserOrg
    }
  }
}
    ${c}`;function d(e){let t={...l,...e};return s.useQuery(u,t)}let g=r.gql`
    query CurrentUserOrgContextGetOrg($orgSlug: String!) {
  currentUser {
    id
    org(orgSlug: $orgSlug) {
      ... on Org {
        id
        ...CurrentUserOrg
      }
      ... on Error {
        message
      }
    }
  }
}
    ${c}`;function p(e){let t={...l,...e};return s.useQuery(g,t)}let C=r.gql`
    mutation CurrentUserOrgContextUpdateOrgContext($input: UpdateOrgContextInput!) {
  updateOrgContext(input: $input) {
    ... on Org {
      ...CurrentUserOrg
    }
    ... on Error {
      __typename
      message
    }
  }
}
    ${c}`;e.s(["CurrentUserOrgContextDocument",0,u,"CurrentUserOrgContextUpdateOrgContextDocument",0,C,"useCurrentUserOrgContextGetOrgQuery",0,p,"useCurrentUserOrgContextQuery",0,d,"useCurrentUserOrgContextUpdateOrgContextMutation",0,function(e){let t={...l,...e};return i.useMutation(C,t)}],672220),e.i(908796);let m={"flag-sponsorship-bulk-send":"number","flag-org-depl-rules":"boolean","flag-require-git-remote":"boolean","flag-agent-billing-v2-teams":"boolean","flag-org-stack-templates":"boolean","flag-tom-riddle":"boolean","flag-deployments-switch-to-azure":"boolean","flag-experimental-connectors":"string","flag-org-require-security-scan-in-deployment":"boolean","flag-enable-deployment-private-passwords":"boolean","flag-org-custom-mcp-servers":"boolean","flag-org-predefined-mcp-providers":"boolean","flag-org-budgets":"boolean","flag-azure-org-can-use-object-store":"boolean","flag-unified-plans-enterprise":"boolean","flag-self-hosted-git-domains":"boolean","flag-databricks-apps":"boolean","flag-enterprise-deployment-geography-whitelist":"boolean","flag-deployment-geography-selection":"boolean","flag-msft-rayfin":"boolean","flag-self-serve-sso":"boolean","flag-vibes-not-guaranteed":"boolean"};function f(e){if(!e||"object"!=typeof e)return!1;let{id:t,type:n,value:o}=e;if(!(t in m))return!1;let r=m[t];return n===r||"number"===r&&"string"===n&&!isNaN(Number(o))}function h(e){return(e.flags||[]).filter(f).reduce((e,{id:t,value:n})=>({...e,[t]:"number"===m[t]?Number(n):n}),{})}e.s(["orgFlags",0,h],284693);var O=e.i(933302);let y=["/evaluations","/import","/integrations","/notifications","/templates","/theme","/@","/~/cli","/grab"],S=(0,o.createContext)(null),b=(0,o.createContext)(null);function x(){let e=(0,o.useContext)(S);if(null===e)throw Error("StoredOrgContextProvider missing!");return e}e.s(["StoredOrgContextProvider",0,function({children:e}){let r=(0,n.useRouter)(),a=r.asPath,s=function(){let e=(0,n.useRouter)().asPath.split("?")[0];if(e.startsWith("/t")){let t=e.split("/");if(t[2])return t[2]}return null}(),i=(0,O.useSyncStatsigOrgContext)(),l=null!=s,c=!l&&y.some(e=>a.startsWith(e)),u=d({skip:"/replEnvironmentDesktop"===r.pathname||"/replEnvironmentMobile"===r.pathname||!c}),g=u.data?.getUserOrgContext2?.__typename==="Org"?u.data.getUserOrgContext2:null,C=p({skip:!l,variables:{orgSlug:s??""}}),m=C.data?.currentUser?.org?.__typename==="Org"?C.data.currentUser.org:null,f=c?u.loading:C.loading,x=l?m:c?g:null;i(x?.id,x?.dealContext?.dealType);let[_,v]=(0,o.useState)({orgId:x?.id,orgSlug:x?.slug,orgRole:x?.currentUserRole??void 0,orgDealContext:x?.dealContext??void 0});(0,o.useEffect)(()=>{f||v({orgId:x?.id,orgSlug:x?.slug,orgRole:x?.currentUserRole??void 0,orgDealContext:x?.dealContext??void 0})},[x,f]);let R=(0,o.useCallback)(e=>v(e),[]),E=(0,o.useMemo)(()=>x?h(x):{},[x]);return(0,t.jsx)(b.Provider,{value:R,children:(0,t.jsx)(S.Provider,{value:{flags:E,orgId:_.orgId,orgSlug:_.orgSlug,orgRole:_.orgRole,orgDealContext:_.orgDealContext,loading:f},children:e})})},"getOrgTrackingContext",0,e=>e?`Org:${e.id}`:"Personal","useCurrentUserStoredOrgContext",0,x,"useIsCurrentOrgEnterprise",0,function(){let e=x();return e.orgDealContext?.dealType==="enterprise"||e.orgDealContext?.dealType==="enterprise_trial"},"useSetOptimisticOrg",0,function(){let e=(0,o.useContext)(b);if(null===e)throw Error("StoredOrgContextProvider missing!");return e}],151027)},335451,366541,e=>{"use strict";var t=e.i(351623),n=e.i(344480);e.i(975473);let o={},r=t.gql`
    fragment ConnectorContextReplInfo on Repl {
  id
  title
  iconUrl
  url
  timeCreated
  user {
    id
    username
    fullName
    image
  }
}
    `,a=t.gql`
    fragment ConnectorContextConnectionInfo on OintConnection {
  connectionId
  connectorName
  displayName
  iconPath
  status
  type
  environment
  webhookProvider
  repls {
    ...ConnectorContextReplInfo
  }
  predefinedProvider {
    id
    displayName
    description
    baseUrl
    iconPath
  }
}
    ${r}`,s=t.gql`
    fragment ConnectorContext on CurrentUserConnectorContext {
  openIntClientToken
  connectorWhitelist
  connections {
    ...ConnectorContextConnectionInfo
  }
  connectorConfigs {
    id
    type
    connectorName
    displayName
    description
    iconPath
    webhookEvents {
      name
      model
      description
    }
  }
}
    ${a}`,i=t.gql`
    fragment OrgConnectorContext on OrgConnectorContext {
  openIntClientToken
  connectorWhitelist
  connections {
    ...ConnectorContextConnectionInfo
  }
  connectorConfigs {
    id
    type
    connectorName
    displayName
    description
    iconPath
    webhookEvents {
      name
      model
      description
    }
  }
}
    ${a}`,l=t.gql`
    query GetConnectorContext {
  currentUser {
    ... on CurrentUser {
      id
      isSubscribed
      connectorContext {
        ...ConnectorContext
      }
    }
  }
}
    ${s}`,c=t.gql`
    query GetConnectorContextByOrg($orgId: String!) {
  currentUser {
    ... on CurrentUser {
      id
      isSubscribed
      org(orgId: $orgId) {
        __typename
        ... on Org {
          id
          connectorContext {
            ...OrgConnectorContext
          }
        }
        ... on Error {
          __typename
          message
        }
      }
    }
  }
}
    ${i}`;e.s(["ConnectorContextConnectionInfoFragmentDoc",0,a,"ConnectorContextFragmentDoc",0,s,"ConnectorContextReplInfoFragmentDoc",0,r,"GetConnectorContextByOrgDocument",0,c,"GetConnectorContextDocument",0,l,"OrgConnectorContextFragmentDoc",0,i,"useGetConnectorContextByOrgQuery",0,function(e){let t={...o,...e};return n.useQuery(c,t)},"useGetConnectorContextQuery",0,function(e){let t={...o,...e};return n.useQuery(l,t)}],366541);var u=e.i(299020);let d={},g=t.gql`
    query UserConnectorsPage {
  currentUser {
    id
    __typename
    isSubscribed
    connectorContext {
      __typename
      ...ConnectorContext
      ... on Error {
        message
      }
    }
  }
}
    ${s}`,p=t.gql`
    mutation CreateConnection($input: CreateConnectionInput!) {
  createConnection(input: $input) {
    ... on CreateConnection {
      connectionId
    }
    ... on Error {
      message
    }
  }
}
    `,C=t.gql`
    mutation DeleteConnection($input: DeleteConnectionInput!) {
  deleteConnection(input: $input) {
    ... on DeleteConnection {
      success
    }
  }
}
    `,m=t.gql`
    mutation RequestNewConnector($input: RequestNewConnectorInput!) {
  requestNewConnector(input: $input) {
    ... on RequestNewConnectorResult {
      success
    }
  }
}
    `;e.s(["UserConnectorsPageDocument",0,g,"useCreateConnectionMutation",0,function(e){let t={...d,...e};return u.useMutation(p,t)},"useDeleteConnectionMutation",0,function(e){let t={...d,...e};return u.useMutation(C,t)},"useRequestNewConnectorMutation",0,function(e){let t={...d,...e};return u.useMutation(m,t)},"useUserConnectorsPageQuery",0,function(e){let t={...d,...e};return n.useQuery(g,t)}],335451)},829706,e=>{"use strict";var t=e.i(276385),n=e.i(917736),o=e.i(882848),r=e.i(995691),a=e.i(146432),s=e.i(142643),i=e.i(480028);let l=new Set(["FIGMA","CUSTOM_MCP"]),c=new Set(["BITBUCKET_SOURCE_CONTROL","GITHUB_SOURCE_CONTROL","GITLAB_SOURCE_CONTROL"]),u=new Set(s.APP_SCOPED_CONNECTORS.map(e=>e.toUpperCase().replace(/-/g,"_"))),d=new Set(["disconnected","error"]),g=new Set(["YOUTUBE"]),p=[{id:"replit-database",name:"Replit Database",type:"PostgreSQL",icon:(0,t.jsx)(n.default,{size:16,color:i.tokens.blueStronger}),link:"https://docs.replit.com/cloud-services/storage-and-databases/sql-database",pane:{type:"neon"}},{id:"replit-app-storage",name:"Replit App Storage",type:"Object Storage",icon:(0,t.jsx)(a.default,{size:16,color:i.tokens.greenStronger}),link:"https://docs.replit.com/cloud-services/storage-and-databases/object-storage",pane:{type:"objectStorage"}},{id:"replit-auth",name:"Replit Auth",type:"Authentication",icon:(0,t.jsx)(r.default,{size:16,color:i.tokens.orangeStronger}),link:"https://docs.replit.com/replit-workspace/replit-auth#replit-auth",pane:{type:"replitAuth"}},{id:"replit-domains",name:"Replit Domains",type:"Domains",icon:(0,t.jsx)(o.default,{size:16,color:i.tokens.tealStronger}),link:"https://docs.replit.com/cloud-services/deployments/domain-purchasing",pane:{type:"deployments"}}];p.map(e=>e.id),e.s(["APP_SCOPED_CONNECTORS_UPPER_SNAKE",0,u,"CONNECTOR_DESCRIPTIONS",0,{AGENTMAIL:"Send, receive, and reply to emails using the AgentMail email inbox API.",AMPLITUDE:"Query analytics data, manage event taxonomy, and trigger project runs in Amplitude",ASHBY:"Access job postings, candidates, and applications from your Ashby ATS",ASANA:"Read tasks and project data from Asana workspaces",SPROUTSOCIAL:"Manage social media profiles, posts, messages, and cases from Sprout Social",BITBUCKET:"Access Bitbucket repositories, users, and organizations from Replit",BITBUCKET_SOURCE_CONTROL:"Sync code to Bitbucket repositories from your Replit apps",GITHUB_SOURCE_CONTROL:"Sync code to GitHub repositories from your Replit apps",GITLAB_SOURCE_CONTROL:"Sync code to GitLab projects from your Replit apps",DATABRICKS_M2M:"Execute SQL queries and manage data workflows in Databricks using a service account",BIGQUERY:"Execute SQL queries on Google BigQuery datasets from your Replit apps",BOX:"Access Box files and folders from Replit",CALENDLY:"View Calendly events and event types",CONFLUENCE:"Read users and groups, create and edit content in Confluence spaces",CLICKUP:"Access tasks, projects, and workflows in ClickUp",DATABRICKS:"Execute SQL queries and manage data workflows in Databricks",DISCORD:"Access Discord guild information and user profiles",DROPBOX:"Access Dropbox files, content, and metadata",ELEVENLABS:"AI voice generation and text-to-speech",HEX:"Run data notebooks, manage projects, and trigger Hex project runs via API",OPENAI:"Access your own OpenAI API key instead of default Replit-managed AI integrations",FACEBOOK:"View Facebook profiles, posts, photos, and manage pages",GITHUB:"Access GitHub repositories, users, and organizations from your Replit apps",GOOGLE_CALENDAR:"Read and write Google Calendar events and settings",GOOGLE_DOCS:"Create, read, and edit Google Docs",GOOGLE_DRIVE:"Access and manage Google Drive files and folders",GOOGLE_MAIL:"Send, receive, and manage Gmail messages",GOOGLE_SHEET:"Read and write data in Google Sheets",GOOGLE_SLIDES:"Create, read, and edit Google Slides presentations",HUBSPOT:"Access HubSpot CRM objects, contacts, and deals from Replit",INSTAGRAM:"Manage Instagram business content, messages, and insights",JIRA:"View users and manage Jira work items and issues",LINEAR:"Create and manage Linear issues, comments, and schedules",MONDAY:"Access Monday.com boards and user information",MOBILE_MAPS:"Access mobile maps and locations from Replit",NOTION:"Read and write to Notion workspaces and pages",ONEDRIVE:"Access and manage OneDrive files and folders",OUTLOOK:"Send and receive emails, manage Outlook calendar events",PLAID:"Access Plaid connected bank accounts and transactions",POSTGRES:"Execute read-only SQL queries on PostgreSQL databases",RESEND:"Send transactional emails using the Resend API",REVENUECAT:"Monetize your mobile apps built on Replit",SALESFORCE:"Access Salesforce CRM data and perform operations via REST API",SEGMENT:"Manage Segment sources, destinations, and tracking plans via the Public API",SENDGRID:"Send transactional emails using the SendGrid API",SHAREPOINT:"Read, write, and manage SharePoint sites and documents",SLACK:"Send messages and interact with Slack workspaces",SLACK_AGENT:"Integrate Slack agent capabilities from Replit",SLACK_AGENT_BUILDER:"Build and manage custom Slack agents",STRIPE:"Connect to Stripe to enable seamless and secure payments for your apps",SNOWFLAKE:"Execute SQL queries on Snowflake data warehouses",SPOTIFY:"Access and manage Spotify playlists and libraries",TODOIST:"Read and write to your Todoist tasks and projects",TWILIO:"Send SMS messages and make voice calls using the Twilio API",YOUTUBE:"Upload and manage YouTube videos, channels, and analytics",ZENDESK:"Access Zendesk users and support tickets from Replit",FIGMA:"Allow Replit Agent to view and rapidly build your designs from Figma",CUSTOM_MCP:"Allows Replit Agent to access external MCP servers",ZOOM:"Access Zoom meetings, users, settings, and webinars with admin privileges",WORKATO:"Trigger Workato recipes and call Workato APIs",X:"Access X posts, users, and search using the X API v2 with pay-per-usage pricing",MICROSOFT_FABRIC:"Access Microsoft Fabric workspaces and resources"},"DISCONNECTED_STATUSES",0,d,"MCP_CONNECTORS",0,l,"REPLIT_MANAGED_SERVICES",0,p,"VERSION_CONTROL_CONNECTORS",0,c,"buildConnectionManagementUrl",0,function(e,t,n){let o=`/integrations/${e.toLowerCase()}/apps/${t}`;return n?`/t/${n}${o}`:o},"isAppScopedConnector",0,e=>u.has(e),"isConnectionHealthy",0,e=>!d.has(e??""),"isHiddenUnlessConnected",0,e=>g.has(e),"isMCPConnector",0,e=>l.has(e),"toConnectorName",0,function(e){if(!e)return null;let t=e.toUpperCase();return/^[A-Z][A-Z0-9_]*$/.test(t)?t:null}])},246549,e=>{"use strict";var t=e.i(389959),n=e.i(335451),o=e.i(366541),r=e.i(829706),a=e.i(151027);let s={};e.s(["useConnectors",0,function(e){let i=e?.skip??!1,{orgId:l}=(0,a.useCurrentUserStoredOrgContext)(),c=!!l,{data:u,loading:d,error:g,refetch:p}=(0,o.useGetConnectorContextQuery)({skip:i||c,context:s}),{data:C,loading:m,error:f,refetch:h}=(0,o.useGetConnectorContextByOrgQuery)({variables:{orgId:l??""},skip:i||!c,context:s}),O=u?.currentUser?.__typename==="CurrentUser"?u?.currentUser?.connectorContext:null,y=C?.currentUser?.__typename==="CurrentUser"&&C?.currentUser?.org?.__typename==="Org"?C?.currentUser?.org?.connectorContext:null,S=c?y:O,b=c?f:g,x=c?m:d,_=c?h:p,[v,{loading:R}]=(0,n.useCreateConnectionMutation)(),E=(0,t.useCallback)(async e=>v({...e,refetchQueries:c?[{query:o.GetConnectorContextByOrgDocument,variables:{orgId:l??""}}]:[{query:o.GetConnectorContextDocument}]}),[v,c,l]),A=S&&(c?"OrgConnectorContext"===S.__typename:"CurrentUserConnectorContext"===S.__typename),I=c?C?.currentUser?.__typename==="CurrentUser"&&C.currentUser.isSubscribed:u?.currentUser?.__typename==="CurrentUser"&&u.currentUser.isSubscribed,w=(0,t.useMemo)(()=>{if(!A||"CurrentUserConnectorContext"!==S.__typename&&"OrgConnectorContext"!==S.__typename)return[];let e=[],t=S.connectorWhitelist??[],n=S.connections??[],o=S.connectorConfigs??[],a=n.filter(e=>(t.includes(e.connectorName)||r.MCP_CONNECTORS.has(e.connectorName))&&!r.APP_SCOPED_CONNECTORS_UPPER_SNAKE.has(e.connectorName)),s=new Set,i=a.filter(e=>r.MCP_CONNECTORS.has(e.connectorName)?(s.add(e.connectorName),!0):!s.has(e.connectorName)&&(s.add(e.connectorName),!0)),l=new Map;o.forEach(e=>{e.connectorName&&e.webhookEvents&&e.webhookEvents.length>0&&l.set(e.connectorName,e.webhookEvents)});let c=o.filter(e=>e.connectorName&&t.includes(e.connectorName)&&!s.has(e.connectorName)&&"CUSTOM_MCP"!==e.connectorName);return i.forEach(t=>{e.push({id:t.connectionId,displayName:t.displayName,iconPath:t.iconPath,connectorName:t.connectorName,connectorType:"connection",type:t.type,webhookEvents:l.get(t.connectorName)})}),c.forEach(t=>{t.connectorName&&e.push({id:t.id,displayName:t.displayName??"Untitled",iconPath:t.iconPath,connectorName:t.connectorName,connectorType:"connectorConfig",type:t.type,webhookEvents:l.get(t.connectorName)})}),e},[A,S]);return b||!A||"CurrentUserConnectorContext"!==S.__typename&&"OrgConnectorContext"!==S.__typename?{token:null,connections:[],connectorConfigs:[],connectorWhitelist:[],slashCommandConnectorItems:[],createConnection:E,loading:x,createConnectionLoading:R,error:b,refetch:_,isSubscribed:I??!1,isOrgContext:c}:{token:S.openIntClientToken,connections:S.connections??[],connectorConfigs:S.connectorConfigs??[],connectorWhitelist:S.connectorWhitelist??[],slashCommandConnectorItems:w,createConnection:E,loading:x,createConnectionLoading:R,error:b,refetch:_,isSubscribed:I??!1,isOrgContext:c}}])},843400,e=>{e.v({modalContent:"EmbedModal-module__oAShma__modalContent",overlay:"EmbedModal-module__oAShma__overlay",overlayTopAligned:"EmbedModal-module__oAShma__overlayTopAligned"})},554370,e=>{"use strict";var t=e.i(276385),n=e.i(389959),o=e.i(486597),r=e.i(624071),a=e.i(342942),s=e.i(739261),i=e.i(969407),l=e.i(918542),c=e.i(691636),u=e.i(61732),d=e.i(843400);e.s(["EmbedModal",0,function({isOpen:e,onRequestClose:g,children:p,maxWidth:C=800,maxHeight:m,centered:f=!0,zIndex:h,className:O,portalContainer:y}){let S=(0,i.useIsSSR)(),b=(0,n.useRef)(null),x=(0,o.useOverlayTriggerState)({isOpen:e,onOpenChange:e=>{e||g()}}),{modalProps:_,underlayProps:v}=(0,l.useModalOverlay)({isDismissable:!0,isKeyboardDismissDisabled:!1,shouldCloseOnInteractOutside:e=>!(e.tagName.toLowerCase().includes("1password")||e.tagName.toLowerCase().includes("com-1password")||e.hasAttribute("data-op-target")||e.hasAttribute("data-op-id")||Array.from(e.attributes).some(e=>e.name.startsWith("data-1p-"))||e.className?.toString().includes("op-")||null!==e.closest('[class*="1password"]')||null!==e.closest('[class*="op-"]')||null!==e.closest("[data-op-target]"))},x,b),{dialogProps:R}=(0,s.useDialog)({"aria-label":"Embed content"},b);return((0,n.useEffect)(()=>{let t=t=>{"Escape"===t.key&&e&&g()};return document.addEventListener("keydown",t),()=>document.removeEventListener("keydown",t)},[e,g]),S||!e)?null:(0,t.jsx)(a.Overlay,{portalContainer:y??document.body,children:(0,t.jsx)("div",{...v,className:f?d.default.overlay:`${d.default.overlay} ${d.default.overlayTopAligned}`,style:{zIndex:h??c.DefaultModalZIndex},children:(0,t.jsx)("div",{...(0,r.mergeProps)(_,R),ref:b,className:`${d.default.modalContent} ${O||""}`,style:{maxWidth:C,maxHeight:m??"calc(100vh - 64px)"},children:(0,t.jsx)(u.View,{children:p})})})})}])}]);

//# debugId=2032c509-52ef-dd1e-36f2-4967e03fec17
//# sourceMappingURL=0c.qd259_yi7e.js.map