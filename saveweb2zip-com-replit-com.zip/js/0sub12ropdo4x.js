;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="700c72db-8a29-e4f1-a76e-ec3789196d28")}catch(e){}}();
(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,588992,e=>{"use strict";var t=e.i(389959),i=e.i(489859);e.s(["default",0,function(e,n){let[o,r]=(0,t.useState)(n),[s,a]=(0,t.useState)(!1);return(0,t.useEffect)(()=>{let t=i.default.get(e);null!=t&&r(t),a(!0)},[e]),(0,t.useEffect)(()=>{s&&i.default.set(e,o)},[e,o,s]),[o,r,s]}])},798926,e=>{e.v({prose:"Prose-module__aikpka__prose"})},827320,e=>{"use strict";var t=e.i(276385),i=e.i(389959),n=e.i(8047),o=e.i(798926);e.s(["Prose",0,({children:e,...r})=>(0,t.jsx)(n.Text,{multiline:!0,clsx:o.default.prose,...r,children:i.Children.map(e,e=>"string"==typeof e?(0,t.jsx)("span",{children:e}):e)})])},74768,e=>{"use strict";var t=e.i(351623),i=e.i(344480);e.i(975473);var n=e.i(299020);let o={},r=t.gql`
    fragment ReplAgentSettingsReplConfig on ReplConfig {
  isInPlanningPhase
  initialStackBlueprint
  agentSettings {
    thinkingEnabled
    modelProfile
    enableAutomatedTesting
    enableAutoCheckpointing
    autoApprovePlan
    webSearchEnabled
    imageGenerationEnabled
    chatMode
    autonomyLevel
    maxAutonomyEnabled
  }
}
    `,s=t.gql`
    query ReplAgentSetting($replId: String!) {
  currentUser {
    id
  }
  getRepl(id: $replId) {
    ... on Repl {
      id
      timeCreated
      config {
        ...ReplAgentSettingsReplConfig
      }
    }
  }
}
    ${r}`,a=t.gql`
    mutation UpdateReplAgentSettings($input: UpdateReplInput!) {
  updateRepl(input: $input) {
    repl {
      id
      config {
        ...ReplAgentSettingsReplConfig
      }
    }
  }
}
    ${r}`;e.s(["ReplAgentSettingDocument",0,s,"ReplAgentSettingsReplConfigFragmentDoc",0,r,"useReplAgentSettingQuery",0,function(e){let t={...o,...e};return i.useQuery(s,t)},"useUpdateReplAgentSettingsMutation",0,function(e){let t={...o,...e};return n.useMutation(a,t)}])},20397,e=>{"use strict";var t=e.i(847159),t=t;let i=t.default;e.s(["FormattedMessage",0,i],20397)},5620,e=>{"use strict";var t=e.i(389959),i=e.i(627871),n=e.i(285296);e.s(["default",0,function(){var e=t.useContext(n.Context);return(0,i.invariantIntlContext)(e),e}])},864300,e=>{"use strict";var t=e.i(5620);e.s(["useIntl",()=>t.default])},847159,e=>{"use strict";var t=e.i(274466),i=e.i(389959),n=e.i(627871),o=e.i(5620);function r(e){var t=(0,o.default)(),n=t.formatMessage,r=t.textComponent,s=void 0===r?i.Fragment:r,a=e.id,l=e.description,u=e.defaultMessage,m=e.values,d=e.children,c=e.tagName,p=void 0===c?s:c,g=n({id:a,description:l,defaultMessage:u},m,{ignoreTag:e.ignoreTag});return"function"==typeof d?d(Array.isArray(g)?g:[g]):p?i.createElement(p,null,g):i.createElement(i.Fragment,null,g)}r.displayName="FormattedMessage";var s=i.memo(r,function(e,i){var o=e.values,r=(0,t.__rest)(e,["values"]),s=i.values,a=(0,t.__rest)(i,["values"]);return(0,n.shallowEqual)(s,o)&&(0,n.shallowEqual)(r,a)});s.displayName="MemoizedFormattedMessage",e.s(["default",0,s])},935984,e=>{"use strict";var t=e.i(351623),i=e.i(344480),n=e.i(975473),o=e.i(299020);let r={},s=t.gql`
    fragment TourServiceTour on TourSeen {
  id
  seen
}
    `,a=t.gql`
    query TourServiceToursSeen($tours: [String!]!) {
  currentUser {
    id
    toursSeen(tours: $tours) {
      id
      ...TourServiceTour
    }
  }
}
    ${s}`,l=t.gql`
    mutation TourServiceDismissTour($name: String!) {
  markTourAsSeen2(input: {name: $name}) {
    __typename
    ... on TourSeen {
      id
      ...TourServiceTour
    }
    ... on UserError {
      message
    }
    ... on UnauthorizedError {
      message
    }
  }
}
    ${s}`;e.s(["TourServiceDismissTourDocument",0,l,"TourServiceToursSeenDocument",0,a,"useTourServiceDismissTourMutation",0,function(e){let t={...r,...e};return o.useMutation(l,t)},"useTourServiceToursSeenLazyQuery",0,function(e){let t={...r,...e};return n.useLazyQuery(a,t)},"useTourServiceToursSeenQuery",0,function(e){let t={...r,...e};return i.useQuery(a,t)}])},777198,e=>{"use strict";var t=e.i(389959),i=e.i(935984);function n(e,n){let{data:o,loading:r}=(0,i.useTourServiceToursSeenQuery)({variables:{tours:e}}),[s,{loading:a}]=(0,i.useTourServiceDismissTourMutation)({variables:{name:e},optimisticResponse:{__typename:"RootMutationType",markTourAsSeen2:{__typename:"TourSeen",id:e,seen:!0}},onCompleted:n}),[l,{loading:u}]=(0,i.useTourServiceDismissTourMutation)({variables:{name:e},optimisticResponse:{__typename:"RootMutationType",markTourAsSeen2:{__typename:"TourSeen",id:e,seen:!1}}}),m=!!o?.currentUser?.toursSeen[0].seen;return(0,t.useMemo)(()=>({isLoading:r,isDone:m,setAsDone:s,unsetAsDone:l,isMutating:a||u}),[r,m,s,l,a,u])}e.s(["useDismissibleElement",0,function(e){let{isLoading:t,isDone:i,setAsDone:o,unsetAsDone:r}=n(e);return{isLoading:t,isDone:i,setAsDone:o,unsetAsDone:r}},"useMemoedDismissibleElement",0,n])},289884,e=>{"use strict";var t=e.i(389959);e.s(["default",0,function(e,i){let n=(0,t.useRef)(null),o=(0,t.useCallback)(t=>{n.current?.contains(t.target)||e(t)},i);return(0,t.useEffect)(()=>(document.addEventListener("mousedown",o),()=>{document.removeEventListener("mousedown",o)}),[o]),n}])},272290,e=>{"use strict";var t=e.i(351623);let i=t.gql`
    fragment DeploymentLink on HostingDeployment {
  id
  replitAppSubdomain
  domains2 {
    id
    domain
    state
  }
  currentBuild {
    id
    provider
  }
}
    `;var n=e.i(319801);let o=t.gql`
    fragment BuildDebugSummary on HostingDebugSummary {
  id
  sessionId
  eventId
  type
}
    `,r=t.gql`
    fragment ReplDomain2 on Domain {
  id
  hosting_deployment_id
  domain
  state
}
    `,s=t.gql`
    fragment CustomDomain on Domain {
  ...ReplDomain2
}
    ${r}`,a=t.gql`
    fragment TargetHostingDeployment on HostingDeployment {
  id
  replitAppSubdomain
  timeCreated
  securityScanEnabled
  uptimeCheckEnabled
  agentInboxEnabled
  agentInboxConfig {
    position
    logoSrc
    bgColor
  }
  replitBadgeEnabled
  scheduledDeletionTime
  latestBuildStatus
  geography
}
    `,l=t.gql`
    fragment MachineConfiguration on HostingMachineConfiguration {
  id
  label
  vcpu
  memory
  slug
}
    `,u=t.gql`
    fragment HostingBuildArtifactFields on HostingBuildArtifact {
  id
  name
  type
  folderName
  services {
    id
    name
    paths
    hasRunCommand
  }
}
    `,m=t.gql`
    fragment CurrentBuild2 on HostingBuild {
  id
  description
  status
  hasDeployLogs
  suspendedReason
  timeCreated
  hasImageTag
  envVars {
    name
    value
  }
  debugSummary {
    ...BuildDebugSummary
  }
  repl {
    id
    slug
    apexProxy
    domains {
      ... on Domain {
        ...CustomDomain
      }
    }
    org {
      id
    }
    owner {
      ... on Team {
        id
        username
      }
      ... on User {
        id
        username
      }
    }
    hostingDeployment {
      ... on HostingDeployment {
        ...TargetHostingDeployment
        ...DeploymentLink
      }
    }
  }
  provider
  machineConfiguration {
    ...MachineConfiguration
  }
  maxMachineInstances
  machineJob {
    timezone
    crontab
  }
  user {
    id
    displayName
    username
    image
    fullName
  }
  isPrivate
  hasPrivatePassword
  rollbackSourceBuildId
  isStandby
  artifacts {
    ...HostingBuildArtifactFields
  }
}
    ${o}
${s}
${a}
${i}
${l}
${u}`,d=t.gql`
    fragment DeploymentStatus on HostingDeployment {
  id
  currentBuild {
    id
    status
    suspendedReason
    timeCreated
    user {
      id
      displayName
    }
    provider
  }
  inProgressBuild {
    id
  }
  latestBuildStatus
}
    `,c=t.gql`
    fragment DeploymentItem on HostingDeployment {
  id
  replitAppSubdomain
  domains2 {
    id
    domain
    state
  }
  repl {
    id
    title
    iconUrl
    config {
      isAgentStack
    }
    ...ReplLinkRepl
  }
  ...DeploymentLink
  ...DeploymentStatus
}
    ${n.ReplLinkReplFragmentDoc}
${i}
${d}`;e.s(["BuildDebugSummaryFragmentDoc",0,o,"CurrentBuild2FragmentDoc",0,m,"DeploymentItemFragmentDoc",0,c,"HostingBuildArtifactFieldsFragmentDoc",0,u,"MachineConfigurationFragmentDoc",0,l,"TargetHostingDeploymentFragmentDoc",0,a],272290)},845822,e=>{"use strict";e.s(["ASSISTANT_USAGE_UNIT",0,"edit request","AUTOSCALE_ESTIMATED_DAILY_COMPUTE_MINUTES",0,10,"CHEAPER_CORE_FLEXIBLE_SPEND_USD",0,20,"CORE_FLEXIBLE_SPEND_USD",0,25,"NUM_REPLS_IN_PAGE",0,10,"PRO_FLEXIBLE_SPEND_USD",0,100,"TEAMS_CREDITS_PER_YEARLY_SEAT_USD",0,480,"TEAMS_FLEXIBLE_SPEND_PER_MONTHLY_SEAT_USD",0,40,"defaultAutoscaleDeploymentCostDetails",0,{computeUnitsPerCpu:18,computeUnitsPerRam:2,costPerComputeUnitUsd:32e-7,fixedCostPerMonth:"1"},"defaultAzureContainerAppDeploymentCostDetails",0,{"aca-1-2":{costPerHour:.2,costPerMonth:"144"},"aca-2-4":{costPerHour:.3,costPerMonth:"216"},"aca-4-8":{costPerHour:.5,costPerMonth:"360"}},"defaultAzureVmDeploymentCostDetails",0,{Standard_E2_v5:{costPerHour:.2,costPerMonth:"144"},Standard_E4_v5:{costPerHour:.4,costPerMonth:"288"},Standard_E8_v5:{costPerHour:.7,costPerMonth:"504"}},"defaultRvmDeploymentCostDetails",0,{"e2-micro":{costPerHour:.014,costPerMonth:"10"},"e2-small":{costPerHour:.028,costPerMonth:"20"},"e2-medium":{costPerHour:.042,costPerMonth:"30"},"n1-custom-1-4096":{costPerHour:.055,costPerMonth:"40"},"e2-standard-2":{costPerHour:.11,costPerMonth:"80"},"e2-standard-4":{costPerHour:.22,costPerMonth:"160"},"c3d-standard-8":{costPerHour:.44,costPerMonth:"320"},"c3d-standard-16":{costPerHour:.88,costPerMonth:"640"}},"defaultScheduledDeploymentCostDetails",0,{costPerComputeUnitUsd:32e-7,fixedCostPerMonth:"1",fixedConfigurationCostPerSec:"0.000070"},"defaultStaticDeploymentCostDetails",0,{outboundDataCostPerGib:"0.10"},"displayCost",0,(e,t=2)=>e.toLocaleString("en-US",{style:"currency",currency:"USD",maximumFractionDigits:15,minimumFractionDigits:t})])},450717,e=>{"use strict";e.i(329467),e.i(242917),e.i(839713),e.s([])},319801,e=>{"use strict";var t=e.i(351623);let i=t.gql`
    fragment ReplLinkRepl on Repl {
  id
  url
  nextPagePathname
}
    `;e.s(["ReplLinkReplFragmentDoc",0,i])},410458,749236,e=>{"use strict";var t=e.i(908796),i=e.i(351623),n=e.i(344480);e.i(975473);let o={},r=i.gql`
    query CustomerSettings($orgId: String!) {
  currentUser {
    id
    org(orgId: $orgId) {
      ... on Org {
        id
        currentUserRole
        customer {
          ... on Customer {
            id
            subscriptionSummary {
              __typename
            }
            settings {
              requirePrivateDeployments
              requirePrivateDevUrls
              disablePasswordProtectedDeployments
              adminOnlyPasswordProtectedDeploymentsBypass
              banSourceCodeExport
              banAttachmentUploads
              adminOnlyPublicDeployments
              higherPowerModelDisabled
              modelfarmDisabled
              openrouterDisabled
              openaiDisabled
              anthropicDisabled
              geminiDisabled
              scimViewerUpgradeLink
              requireGitRemoteBeforeDeployment
              adminOnlyGitRemoteBeforeDeploymentBypass
              requirePrivateRemote
              adminOnlyPrivateRemoteBypass
              allowedGitProvider
              allowedGitRemoteTarget
              requireSecurityScanOnDeployment
              adminOnlySecurityScanOnDeploymentBypass
              disableImport
              disableIntegrations
              disableFrameworks
            }
          }
        }
      }
    }
  }
}
    `;function s(e){let t={...o,...e};return n.useQuery(r,t)}e.s(["CustomerSettingsDocument",0,r,"useCustomerSettingsQuery",0,s],749236);var a=e.i(151027);e.s(["default",0,function(e){let{orgRole:i}=(0,a.useCurrentUserStoredOrgContext)(),{data:n,loading:o,error:r}=s({skip:!e,variables:{orgId:e}});if(o||r)return{loading:o,error:r,requirePrivateDeployments:void 0,requirePrivateDevUrls:void 0,adminOnlyPublicDeployments:void 0,disablePasswordProtectedDeployments:void 0,adminOnlyPasswordProtectedDeploymentsBypass:void 0,banAttachmentUploads:void 0,requireGitRemoteBeforeDeployment:void 0,adminOnlyGitRemoteBeforeDeploymentBypass:void 0,requirePrivateRemote:void 0,adminOnlyPrivateRemoteBypass:void 0,allowedGitProvider:void 0,allowedGitRemoteTarget:void 0,requireSecurityScanOnDeployment:void 0,adminOnlySecurityScanOnDeploymentBypass:void 0,queriedOrgIsAdmin:void 0,disableImport:void 0,disableIntegrations:void 0,disableFrameworks:void 0,higherPowerModelDisabled:void 0,modelfarmDisabled:void 0,openrouterDisabled:void 0,openaiDisabled:void 0,anthropicDisabled:void 0,geminiDisabled:void 0,scimViewerUpgradeLink:""};let l=n?.currentUser?.org,u=l?.__typename==="Org"?l.customer:void 0,m=u?.__typename==="Customer"?u.settings:void 0,d=u?.__typename==="Customer"&&u.subscriptionSummary?.__typename==="CustomerSubscriptionSummarySalesContract",c=m?.requirePrivateDeployments??!1,p=m?.requirePrivateDevUrls??!1,g=m?.disablePasswordProtectedDeployments??!1,y=m?.adminOnlyPasswordProtectedDeploymentsBypass??!1,f=m?.banSourceCodeExport??!1,h=m?.banAttachmentUploads??!1,b=m?.adminOnlyPublicDeployments??!1,v=m?.higherPowerModelDisabled??!1,S=m?.modelfarmDisabled??null,D=!1;D=null!=S?S:!!d;let P=m?.openrouterDisabled??!1,E=m?.openaiDisabled??!1,C=m?.anthropicDisabled??!1,T=m?.geminiDisabled??!1,R=m?.scimViewerUpgradeLink??null,_=m?.requireGitRemoteBeforeDeployment??!1,x=m?.adminOnlyGitRemoteBeforeDeploymentBypass??!1,w=m?.requirePrivateRemote??!1,k=m?.adminOnlyPrivateRemoteBypass??!1,A=m?.allowedGitProvider??null,M=m?.allowedGitRemoteTarget??null,B=m?.requireSecurityScanOnDeployment??!1,N=m?.adminOnlySecurityScanOnDeploymentBypass??!1,F=l?.__typename==="Org"&&l.currentUserRole===t.SystemOrgGroupType.SystemAdmins,U=m?.disableImport??!1,I=m?.disableIntegrations??!1,O=m?.disableFrameworks??!1;return{loading:o,error:r,requirePrivateDeployments:c,requirePrivateDevUrls:p,disablePasswordProtectedDeployments:g,adminOnlyPasswordProtectedDeploymentsBypass:y,banSourceCodeExport:f,banAttachmentUploads:h,adminOnlyPublicDeployments:b,higherPowerModelDisabled:v,modelfarmDisabled:D,openrouterDisabled:P,openaiDisabled:E,anthropicDisabled:C,geminiDisabled:T,isAdmin:i&&i===t.SystemOrgGroupType.SystemAdmins,scimViewerUpgradeLink:R,requireGitRemoteBeforeDeployment:_,adminOnlyGitRemoteBeforeDeploymentBypass:x,requirePrivateRemote:w,adminOnlyPrivateRemoteBypass:k,allowedGitProvider:A,allowedGitRemoteTarget:M,requireSecurityScanOnDeployment:B,adminOnlySecurityScanOnDeploymentBypass:N,queriedOrgIsAdmin:F,disableImport:U,disableIntegrations:I,disableFrameworks:O}}],410458)},871752,e=>{"use strict";var t=e.i(324753),i=e.i(272391);function n(e,i){return(0,t.default)(e,{credentials:"same-origin",headers:{"Content-Type":"application/json",Accept:"application/json","X-Requested-With":"XMLHttpRequest"},method:"post",body:JSON.stringify(i)})}e.s(["postJson",0,function(e,t={}){var o,r;let s;return o=n(e,t),r=e,s=new i.default("Unknown http error"),Promise.resolve(o).then(async e=>{let t;if(e.ok)return e.json();let i=e.headers.get("content-type");if(i&&i.includes("application/json"))t=await e.json();else{let i=await e.text();try{t=JSON.parse(i)}catch(e){t={message:i}}}throw t.message&&(s.message=t.message),s.setExtras({url:r,responseBody:t,responseData:{status:e.status,statusText:e.statusText,redirected:e.redirected,type:e.type,url:e.url}}).setTag("httpError","true"),s})},"wrapPost",0,n])},465584,e=>{e.v({blockBorder:"KeyComboBlocks-module__3yf3FW__blockBorder",blockRoot:"KeyComboBlocks-module__3yf3FW__blockRoot",blockText:"KeyComboBlocks-module__3yf3FW__blockText",chord:"KeyComboBlocks-module__3yf3FW__chord",shortcut:"KeyComboBlocks-module__3yf3FW__shortcut"})},559357,e=>{"use strict";var t=e.i(276385),i=e.i(68701),n=e.i(295621),o=e.i(480028),r=e.i(919073),s=e.i(61732),a=e.i(465584);let l=(0,o.cvarsFrom)("KeyComboBlocks.module.css",["--font-size","--gap","--x-padding"]),u=e=>({Ctrl:e?"⌃":"Ctrl",Cmd:e?"⌘":"Cmd",Alt:e?"⌥":"Alt",Shift:e?"⇧":"Shift",Enter:"↵",ArrowLeft:"←",ArrowRight:"→",ArrowUp:"↑",ArrowDown:"↓"," ":"Space"});function m({text:e,small:n=!1,isActive:d=!1,hideBorder:c=!1,...p}){let g=(0,i.useIsMac)(),y=p.fontSize??(n?12:14),f=Math.round(1.4*y),h=Math.round(y*(c?.1:.2)),b={[l.fontSize]:y+"px",[l.xPadding]:h+"px",height:f,minWidth:c?void 0:f};d&&(b.fontWeight=o.tokens.fontWeightMedium);let v={borderColor:o.tokens.foregroundDefault,opacity:1};return(0,t.jsxs)(r.ShadesSurface,{elevate:!!d&&"1x",clsx:a.default.blockRoot,style:b,children:["string"==typeof e?(0,t.jsx)(s.View,{clsx:a.default.blockText,children:u(g)[e]??e}):e,c?null:(0,t.jsx)(s.View,{clsx:a.default.blockBorder,style:d?v:void 0,br:4})]})}e.s(["KeyBlock",0,m,"KeyComboBlocks",0,function e(i){if((0,n.isKeyChord)(i.keyCombo))return(0,t.jsx)(s.View,{"data-testid":`Keybinding:${i.keyCombo.join(" ")}`,clsx:a.default.chord,className:i.className,children:i.keyCombo.map((n,o)=>(0,t.jsx)(e,{...i,keyCombo:n},o))});let o=(0,n.keyCombinationOrPrefixToKeys)(i.keyCombo),r=i.fontSize??(i.small?12:14),u=i.hideBorder?0:Math.round(.2*r);return(0,t.jsx)(s.View,{"data-testid":`Keybinding:${i.keyCombo}`,clsx:a.default.shortcut,className:i.className,style:{[l.gap]:u+"px"},title:i.keyCombo,children:o.map(e=>(0,t.jsx)(m,{text:e,hideBorder:i.hideBorder,fontSize:r,isActive:i?.match?.includes(e.toLowerCase())},e))})},"keyComboText",0,function(e,t){return((0,n.isKeyChord)(e)?e:[e]).map(e=>(0,n.keyCombinationOrPrefixToKeys)(e).map(e=>u(t)[e]??e.toUpperCase()).join("")).join(" ")}])},119474,e=>{"use strict";var t=e.i(276385),i=e.i(389959),n=e.i(295621),o=e.i(23818);function r(){let e=(0,o.useResolveKeyCombo)(),t=(0,i.useRef)(null);return(0,i.useEffect)(function(){let i=i=>{let r=(0,n.getKeyCombination)(i);if(!r)return;let s=r;t.current&&(s=(0,n.keyChord)(t.current,r));let a=e(s);switch(a.kind){case o.ResolutionResultKindEnum.NoMatch:t.current=null;break;case o.ResolutionResultKindEnum.WaitingForChord:t.current=a.key,i.preventDefault();break;case o.ResolutionResultKindEnum.MatchFound:for(let{run:e,bubble:n=!0}of(t.current=null,a.matches))if(!1!==e()&&(i.preventDefault(),!n))break}};return document.addEventListener("keydown",i),()=>{document.removeEventListener("keydown",i)}},[e]),null}e.i(559357),e.s(["KeybindingsProvider",0,function(e){let i=(0,o.useInitStore)(e);return(0,t.jsxs)(o.KeybindingsContext.Provider,{value:i,children:[e.children,(0,t.jsx)(r,{})]})}])},394384,e=>{"use strict";var t=e.i(918232);let i=RegExp("^.*\\(.*\\).*$"),n=["latn","arab","hanidec","deva","beng"];class o{parse(e){return s(this.locale,this.options,e).parse(e)}isValidPartialNumber(e,t,i){return s(this.locale,this.options,e).isValidPartialNumber(e,t,i)}getNumberingSystem(e){return s(this.locale,this.options,e).options.numberingSystem}constructor(e,t={}){this.locale=e,this.options=t}}let r=new Map;function s(e,t,i){let o=a(e,t);if(!e.includes("-nu-")&&!o.isValidPartialNumber(i)){for(let r of n)if(r!==o.options.numberingSystem){let n=a(e+(e.includes("-u-")?"-nu-":"-u-nu-")+r,t);if(n.isValidPartialNumber(i))return n}}return o}function a(e,t){let i=e+(t?Object.entries(t).sort((e,t)=>e[0]<t[0]?-1:1).join():""),n=r.get(i);return n||(n=new l(e,t),r.set(i,n)),n}class l{parse(e){let n=this.sanitize(e);if(this.symbols.group&&(n=d(n,this.symbols.group,"")),this.symbols.decimal&&(n=n.replace(this.symbols.decimal,".")),this.symbols.minusSign&&(n=n.replace(this.symbols.minusSign,"-")),n=n.replace(this.symbols.numeral,this.symbols.index),"percent"===this.options.style){let e=n.indexOf("-"),t=(n=n.replace("-","")).indexOf(".");-1===t&&(t=n.length),n=n.replace(".",""),n=t-2==0?`0.${n}`:t-2==-1?`0.0${n}`:t-2==-2?"0.00":`${n.slice(0,t-2)}.${n.slice(t-2)}`,e>-1&&(n=`-${n}`)}let r=n?+n:NaN;if(isNaN(r))return NaN;if("percent"===this.options.style){var s,a;let e={...this.options,style:"decimal",minimumFractionDigits:Math.min((null!=(s=this.options.minimumFractionDigits)?s:0)+2,20),maximumFractionDigits:Math.min((null!=(a=this.options.maximumFractionDigits)?a:0)+2,20)};return new o(this.locale,e).parse(new(0,t.NumberFormatter)(this.locale,e).format(r))}return"accounting"===this.options.currencySign&&i.test(e)&&(r*=-1),r}sanitize(e){return e=e.replace(this.symbols.literals,""),this.symbols.minusSign&&(e=e.replace("-",this.symbols.minusSign)),"arab"===this.options.numberingSystem&&(this.symbols.decimal&&(e=(e=e.replace(",",this.symbols.decimal)).replace(String.fromCharCode(1548),this.symbols.decimal)),this.symbols.group&&(e=d(e,".",this.symbols.group))),"fr-FR"===this.options.locale&&(e=d(e,".",String.fromCharCode(8239))),e}isValidPartialNumber(e,t=-1/0,i=1/0){return e=this.sanitize(e),this.symbols.minusSign&&e.startsWith(this.symbols.minusSign)&&t<0?e=e.slice(this.symbols.minusSign.length):this.symbols.plusSign&&e.startsWith(this.symbols.plusSign)&&i>0&&(e=e.slice(this.symbols.plusSign.length)),!(this.symbols.group&&e.startsWith(this.symbols.group)||this.symbols.decimal&&e.indexOf(this.symbols.decimal)>-1&&0===this.options.maximumFractionDigits)&&(this.symbols.group&&(e=d(e,this.symbols.group,"")),e=e.replace(this.symbols.numeral,""),this.symbols.decimal&&(e=e.replace(this.symbols.decimal,"")),0===e.length)}constructor(e,t={}){var i,n;this.locale=e,this.formatter=new Intl.NumberFormat(e,t),this.options=this.formatter.resolvedOptions(),this.symbols=function(e,t,i,n){var o,r,s,a,l;let d=new Intl.NumberFormat(e,{...i,minimumSignificantDigits:1,maximumSignificantDigits:21,roundingIncrement:1,roundingPriority:"auto",roundingMode:"halfExpand"}),p=d.formatToParts(-10000.111),g=d.formatToParts(10000.111),y=m.map(e=>d.formatToParts(e)),f=null!=(l=null==(o=p.find(e=>"minusSign"===e.type))?void 0:o.value)?l:"-",h=null==(r=g.find(e=>"plusSign"===e.type))?void 0:r.value;h||(null==n?void 0:n.signDisplay)!=="exceptZero"&&(null==n?void 0:n.signDisplay)!=="always"||(h="+");let b=null==(s=new Intl.NumberFormat(e,{...i,minimumFractionDigits:2,maximumFractionDigits:2}).formatToParts(.001).find(e=>"decimal"===e.type))?void 0:s.value,v=null==(a=p.find(e=>"group"===e.type))?void 0:a.value,S=[...new Set([...p.filter(e=>!u.has(e.type)).map(e=>c(e.value)),...y.flatMap(e=>e.filter(e=>!u.has(e.type)).map(e=>c(e.value)))])].sort((e,t)=>t.length-e.length),D=0===S.length?RegExp("[\\p{White_Space}]","gu"):RegExp(`${S.join("|")}|[\\p{White_Space}]`,"gu"),P=[...new Intl.NumberFormat(i.locale,{useGrouping:!1}).format(0x24cb016ea)].reverse(),E=new Map(P.map((e,t)=>[e,t]));return{minusSign:f,plusSign:h,decimal:b,group:v,literals:D,numeral:RegExp(`[${P.join("")}]`,"g"),index:e=>String(E.get(e))}}(e,this.formatter,this.options,t),"percent"===this.options.style&&((null!=(i=this.options.minimumFractionDigits)?i:0)>18||(null!=(n=this.options.maximumFractionDigits)?n:0)>18)&&console.warn("NumberParser cannot handle percentages with greater than 18 decimal places, please reduce the number in your options.")}}let u=new Set(["decimal","fraction","integer","minusSign","plusSign","group"]),m=[0,4,2,1,11,20,3,7,100,21,.1,1.1];function d(e,t,i){return e.replaceAll?e.replaceAll(t,i):e.split(t).join(i)}function c(e){return e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}e.s(["NumberParser",0,o])},410528,e=>{"use strict";var t={};t={"ar-AE":{Empty:"فارغ"},"bg-BG":{Empty:"Изпразни"},"cs-CZ":{Empty:"Prázdné"},"da-DK":{Empty:"Tom"},"de-DE":{Empty:"Leer"},"el-GR":{Empty:"Άδειο"},"en-US":{Empty:"Empty"},"es-ES":{Empty:"Vacío"},"et-EE":{Empty:"Tühjenda"},"fi-FI":{Empty:"Tyhjä"},"fr-FR":{Empty:"Vide"},"he-IL":{Empty:"ריק"},"hr-HR":{Empty:"Prazno"},"hu-HU":{Empty:"Üres"},"it-IT":{Empty:"Vuoto"},"ja-JP":{Empty:"空"},"ko-KR":{Empty:"비어 있음"},"lt-LT":{Empty:"Tuščias"},"lv-LV":{Empty:"Tukšs"},"nb-NO":{Empty:"Tom"},"nl-NL":{Empty:"Leeg"},"pl-PL":{Empty:"Pusty"},"pt-BR":{Empty:"Vazio"},"pt-PT":{Empty:"Vazio"},"ro-RO":{Empty:"Gol"},"ru-RU":{Empty:"Не заполнено"},"sk-SK":{Empty:"Prázdne"},"sl-SI":{Empty:"Prazen"},"sr-SP":{Empty:"Prazno"},"sv-SE":{Empty:"Tomt"},"tr-TR":{Empty:"Boş"},"uk-UA":{Empty:"Пусто"},"zh-CN":{Empty:"空"},"zh-TW":{Empty:"空白"}};var i=e.i(451147),n=e.i(389959),o=e.i(593678),r=e.i(614161),s=e.i(278052);e.s(["useSpinButton",0,function(e){var a;let l=(0,n.useRef)(void 0),{value:u,textValue:m,minValue:d,maxValue:c,isDisabled:p,isReadOnly:g,isRequired:y,onIncrement:f,onIncrementPage:h,onDecrement:b,onDecrementPage:v,onDecrementToMin:S,onIncrementToMax:D}=e,P=(0,s.useLocalizedStringFormatter)((a=t)&&a.__esModule?a.default:a,"@react-aria/spinbutton");(0,n.useEffect)(()=>()=>clearTimeout(l.current),[]);let E=(0,n.useRef)(!1),C=()=>{E.current=!0},T=()=>{E.current=!1},R=""===m?P.format("Empty"):(m||`${u}`).replace("-","−");(0,n.useEffect)(()=>{E.current&&((0,i.clearAnnouncer)("assertive"),(0,i.announce)(R,"assertive"))},[R]);let _=(0,o.useEffectEvent)(e=>{clearTimeout(l.current),null==f||f(),l.current=window.setTimeout(()=>{(void 0===c||isNaN(c)||void 0===u||isNaN(u)||u<c)&&_(60)},e)}),x=(0,o.useEffectEvent)(e=>{clearTimeout(l.current),null==b||b(),l.current=window.setTimeout(()=>{(void 0===d||isNaN(d)||void 0===u||isNaN(u)||u>d)&&x(60)},e)}),w=e=>{e.preventDefault()},{addGlobalListener:k,removeAllGlobalListeners:A}=(0,r.useGlobalListeners)();return{spinButtonProps:{role:"spinbutton","aria-valuenow":void 0===u||isNaN(u)?void 0:u,"aria-valuetext":R,"aria-valuemin":d,"aria-valuemax":c,"aria-disabled":p||void 0,"aria-readonly":g||void 0,"aria-required":y||void 0,onKeyDown:e=>{if(!e.ctrlKey&&!e.metaKey&&!e.shiftKey&&!e.altKey&&!g)switch(e.key){case"PageUp":if(h){e.preventDefault(),null==h||h();break}case"ArrowUp":case"Up":f&&(e.preventDefault(),null==f||f());break;case"PageDown":if(v){e.preventDefault(),null==v||v();break}case"ArrowDown":case"Down":b&&(e.preventDefault(),null==b||b());break;case"Home":S&&(e.preventDefault(),null==S||S());break;case"End":D&&(e.preventDefault(),null==D||D())}},onFocus:C,onBlur:T},incrementButtonProps:{onPressStart:()=>{_(400),k(window,"contextmenu",w)},onPressEnd:()=>{clearTimeout(l.current),A()},onFocus:C,onBlur:T},decrementButtonProps:{onPressStart:()=>{x(400),k(window,"contextmenu",w)},onPressEnd:()=>{clearTimeout(l.current),A()},onFocus:C,onBlur:T}}}],410528)}]);

//# debugId=700c72db-8a29-e4f1-a76e-ec3789196d28
//# sourceMappingURL=02e0z97ch0i5c.js.map