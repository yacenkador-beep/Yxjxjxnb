;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="c1308f7b-58a9-14e6-227c-748c75726bb0")}catch(e){}}();
(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,127384,e=>{"use strict";e.s(["APP_HEADER_HEIGHT",0,40,"COLLAPSED_TASK_SIDEBAR_WIDTH",0,44,"HEADER_HEIGHT",0,48,"HEADER_Z_INDEX",0,1002,"SIDEBAR_OVERLAY_Z_INDEX",0,1e3,"SIDEBAR_WIDTH",0,240,"SIDEBAR_Z_INDEX",0,1001])},130902,e=>{"use strict";var r=e.i(351623),t=e.i(444008),n=e.i(344480);e.i(975473);let o={},i=r.gql`
    fragment OrgGroupsOrgGroup on OrgGroup {
  id
  slug
  type
  name
  color
  isMember
  memberCount
  individualMember {
    user {
      id
      displayName
      fullName
      image
    }
    email
  }
  permissions {
    editPermissions
    viewPermissions
  }
}
    `,p=r.gql`
    fragment OrgGroupsConnection on OrgGroupConnection {
  pageInfo {
    hasNextPage
    nextCursor
  }
  items {
    ...OrgGroupsOrgGroup
    isScimManaged
  }
}
    ${i}`,s=r.gql`
    fragment OrgGroupsOrg on Org {
  ...OrgMetadata
  authorizations {
    createOrgGroup {
      isAuthorized
      message
    }
  }
}
    ${t.OrgMetadataFragmentDoc}`,a=r.gql`
    query OrgGroups($orgId: String, $input: OrgGroupsInput) {
  currentUser {
    __typename
    id
    org(orgId: $orgId) {
      __typename
      ... on Org {
        id
        groups(input: $input) {
          __typename
          ...OrgGroupsConnection
          ... on UserError {
            message
          }
        }
      }
      ... on NotFoundError {
        message
      }
    }
  }
}
    ${p}`;e.s(["OrgGroupsOrgFragmentDoc",0,s,"OrgGroupsOrgGroupFragmentDoc",0,i,"useOrgGroupsQuery",0,function(e){let r={...o,...e};return n.useQuery(a,r)}])},667746,e=>{"use strict";var r=e.i(351623),t=e.i(970410),n=e.i(319801),o=e.i(299020),i=e.i(344480),p=e.i(975473);let s={},a=r.gql`
    fragment OrgGroupPermissionsOrgScopeOption on OrgScopeOption {
  __typename
  role
  status
}
    `,u=r.gql`
    fragment OrgGroupPermissionsGroup on OrgGroup {
  ...OrgGroupMetadata
  permissions {
    editPermissions
    viewPermissions
  }
  orgScopeOptions {
    ...OrgGroupPermissionsOrgScopeOption
  }
}
    ${t.OrgGroupMetadataFragmentDoc}
${a}`,l=r.gql`
    fragment OrgGroupOption on OrgGroupScopeOption {
  status
  role
}
    `,g=r.gql`
    fragment OrgGroupOptions on OrgGroupScopeOptions {
  targetGroupId
  options {
    __typename
    ...OrgGroupOption
  }
}
    ${l}`,m=r.gql`
    fragment OrgGroupRepl on Repl {
  id
  title
  iconUrl
  ...ReplLinkRepl
  authorizations {
    editPermissions {
      isAuthorized
    }
  }
}
    ${n.ReplLinkReplFragmentDoc}`,d=r.gql`
    fragment GroupReplsPage on ReplConnection {
  pageInfo {
    hasNextPage
    nextCursor
    previousCursor
  }
  items {
    __typename
    ...OrgGroupRepl
  }
}
    ${m}`,c=r.gql`
    fragment ReplScopeOption on ReplScopeOption {
  status
  role
}
    `,R=r.gql`
    fragment ReplScopeOptions on ReplScopeOptions {
  replId
  options {
    __typename
    ...ReplScopeOption
  }
}
    ${c}`,I=r.gql`
    mutation UpdateOrgGroupScopes($input: UpdateOrgGroupScopesInput!) {
  updateOrgGroupScopes(input: $input) {
    __typename
    ... on OrgGroup {
      ...OrgGroupPermissionsGroup
    }
    ... on Error {
      message
    }
  }
}
    ${u}`,y=r.gql`
    query OrgGroupPermissionsGroups($orgId: String, $input: OrgGroupsInput) {
  currentUser {
    __typename
    id
    org(orgId: $orgId) {
      __typename
      ... on Org {
        id
        groups(input: $input) {
          __typename
          ... on OrgGroupConnection {
            pageInfo {
              hasNextPage
              nextCursor
            }
            items {
              ...OrgGroupMetadata
            }
          }
          ... on UserError {
            message
          }
        }
      }
      ... on NotFoundError {
        message
      }
    }
  }
}
    ${t.OrgGroupMetadataFragmentDoc}`,O=r.gql`
    query OrgGroupScopeOptions($orgId: String!, $groupId: String!, $input: OrgGroupGroupScopeOptionsInput!) {
  currentUser {
    __typename
    id
    org(orgId: $orgId) {
      __typename
      ... on Org {
        id
        group(orgGroupId: $groupId) {
          __typename
          ... on OrgGroup {
            __typename
            id
            groupScopeOptions(input: $input) {
              __typename
              ... on OrgGroupGroupScopeOptions {
                items {
                  ...OrgGroupOptions
                }
              }
              ... on UnauthorizedError {
                message
              }
            }
          }
          ... on NotFoundError {
            message
          }
        }
      }
      ... on NotFoundError {
        message
      }
    }
  }
}
    ${g}`,f=r.gql`
    query OrgGroupPermissionsRepls($orgId: String, $input: OrgReplsInput!) {
  currentUser {
    __typename
    id
    org(orgId: $orgId) {
      __typename
      ... on Org {
        id
        replsCount
        repls(input: $input) {
          __typename
          ... on ReplConnection {
            ...GroupReplsPage
          }
          ... on UserError {
            message
          }
        }
      }
      ... on NotFoundError {
        message
      }
    }
  }
}
    ${d}`,v=r.gql`
    query OrgGroupReplScopeOptions($orgId: String!, $groupId: String!, $input: OrgGroupReplScopeOptionsInput!) {
  currentUser {
    __typename
    id
    org(orgId: $orgId) {
      __typename
      ... on Org {
        id
        group(orgGroupId: $groupId) {
          __typename
          ... on OrgGroup {
            __typename
            id
            replScopeOptions(input: $input) {
              __typename
              ... on OrgGroupReplScopeOptions {
                items {
                  ...ReplScopeOptions
                }
              }
              ... on UnauthorizedError {
                message
              }
            }
          }
          ... on NotFoundError {
            message
          }
        }
      }
      ... on NotFoundError {
        message
      }
    }
  }
}
    ${R}`;e.s(["OrgGroupPermissionsGroupFragmentDoc",0,u,"useOrgGroupPermissionsGroupsQuery",0,function(e){let r={...s,...e};return i.useQuery(y,r)},"useOrgGroupPermissionsReplsQuery",0,function(e){let r={...s,...e};return i.useQuery(f,r)},"useOrgGroupReplScopeOptionsLazyQuery",0,function(e){let r={...s,...e};return p.useLazyQuery(v,r)},"useOrgGroupReplScopeOptionsQuery",0,function(e){let r={...s,...e};return i.useQuery(v,r)},"useOrgGroupScopeOptionsQuery",0,function(e){let r={...s,...e};return i.useQuery(O,r)},"useUpdateOrgGroupScopesMutation",0,function(e){let r={...s,...e};return o.useMutation(I,r)}])},820669,e=>{"use strict";var r=e.i(351623);let t=r.gql`
    fragment CollaboratorCountV2Customer on Customer {
  id
  seats {
    __typename
    ... on CustomerSeats {
      id
      counts {
        admin
        guest
        member
      }
      caps {
        members
      }
    }
  }
  subscriptionSummary {
    __typename
    ... on CustomerSubscriptionSummarySelfServe {
      plan {
        ... on CustomerSubscriptionSummaryFlatSelfServePlan {
          planPrefix
        }
        ... on CustomerSubscriptionSummaryTieredSelfServePlan {
          planPrefix
        }
      }
    }
  }
}
    `;e.s(["CollaboratorCountV2CustomerFragmentDoc",0,t])},99357,e=>{"use strict";var r=e.i(351623),t=e.i(667746),n=e.i(444008),o=e.i(820669),i=e.i(130902);e.i(344480),e.i(975473);var p=e.i(299020);let s={},a=r.gql`
    fragment ReplMultiplayerOrgV2 on Org {
  ...OrgMetadata
  membersCount
  adminGroup: groups(input: {types: [system_admins]}) {
    ... on OrgGroupConnection {
      items {
        id
        memberCount
        isMember
      }
    }
  }
  customer {
    __typename
    ... on Customer {
      ...CollaboratorCountV2Customer
    }
  }
  authorizations {
    editSubscription {
      isAuthorized
    }
  }
}
    ${n.OrgMetadataFragmentDoc}
${o.CollaboratorCountV2CustomerFragmentDoc}`,u=r.gql`
    fragment ReplMultiplayerOrgGroupV2 on OrgGroup {
  ...OrgGroupsOrgGroup
}
    ${i.OrgGroupsOrgGroupFragmentDoc}`,l=r.gql`
    fragment ReplMultiplayerGroupV2 on ReplMultiplayerGroupScope {
  group {
    __typename
    ...ReplMultiplayerOrgGroupV2
  }
  options {
    __typename
    role
    status
  }
}
    ${u}`,g=r.gql`
    fragment ReplMultiplayerIndividualV2 on ReplMultiplayerIndividualScope {
  group {
    __typename
    ...ReplMultiplayerOrgGroupV2
  }
  user {
    __typename
    id
    displayName
    fullName
    image
    username
  }
  options {
    __typename
    role
    status
  }
}
    ${u}`,m=r.gql`
    fragment ReplMultiplayerStatusV2 on Repl {
  id
  title
  isPrivate
  url
  org {
    ...ReplMultiplayerOrgV2
  }
  multiplayerStatus {
    __typename
    groups {
      __typename
      ...ReplMultiplayerGroupV2
    }
    individuals {
      __typename
      ...ReplMultiplayerIndividualV2
    }
    pendingInvites {
      __typename
      email
    }
  }
  authorizations {
    editPermissions {
      isAuthorized
      message
    }
    editVisibility {
      isAuthorized
      message
    }
    removeSelf {
      isAuthorized
      message
    }
    viewPermissions {
      isAuthorized
      message
    }
  }
}
    ${a}
${l}
${g}`,d=r.gql`
    mutation UpdateOrgGroupScopesV2($input: UpdateOrgGroupScopesInput!) {
  updateOrgGroupScopes(input: $input) {
    __typename
    ... on OrgGroup {
      ...OrgGroupPermissionsGroup
    }
    ... on Error {
      message
    }
  }
}
    ${t.OrgGroupPermissionsGroupFragmentDoc}`,c=r.gql`
    mutation GrantReplAccessByEmail($input: GrantReplAccessByEmailInput!) {
  grantReplAccessByEmail(input: $input) {
    ... on Repl {
      __typename
      ...ReplMultiplayerStatusV2
    }
    ... on UnauthorizedError {
      __typename
      message
    }
    ... on NotFoundError {
      __typename
      message
    }
    ... on UserError {
      __typename
      message
    }
  }
}
    ${m}`;e.s(["ReplMultiplayerStatusV2FragmentDoc",0,m,"useGrantReplAccessByEmailMutation",0,function(e){let r={...s,...e};return p.useMutation(c,r)},"useUpdateOrgGroupScopesV2Mutation",0,function(e){let r={...s,...e};return p.useMutation(d,r)}])},669011,e=>{"use strict";var r=e.i(351623),t=e.i(99357),n=e.i(344480);e.i(975473);let o={},i=r.gql`
    fragment ReplEnvironmentHeaderInviteButtonRepl on Repl {
  id
  owner {
    ... on User {
      id
    }
    ... on Team {
      id
    }
  }
  org {
    id
    slug
    type
  }
  authorizations {
    editPermissions {
      isAuthorized
    }
  }
}
    `,p=r.gql`
    query InviteButtonOrgReplPerms($replId: String!) {
  getRepl(id: $replId) {
    __typename
    ... on Repl {
      __typename
      ...ReplMultiplayerStatusV2
    }
  }
}
    ${t.ReplMultiplayerStatusV2FragmentDoc}`;e.s(["ReplEnvironmentHeaderInviteButtonReplFragmentDoc",0,i,"useInviteButtonOrgReplPermsQuery",0,function(e){let r={...o,...e};return n.useQuery(p,r)}])},117714,e=>{"use strict";var r=e.i(351623),t=e.i(344480);e.i(975473);let n={},o=r.gql`
    fragment NewPaneRepl on Repl {
  id
  config {
    isAgentStack
    isServer
    isExpertMode
  }
}
    `,i=r.gql`
    query NewPanePrimaryOutput($replId: String!) {
  getRepl(id: $replId) {
    ... on Repl {
      id
      config {
        isAgentStack
      }
    }
  }
}
    `;e.s(["NewPaneReplFragmentDoc",0,o,"useNewPanePrimaryOutputQuery",0,function(e){let r={...n,...e};return t.useQuery(i,r)}])},764992,e=>{"use strict";var r=e.i(351623);let t=r.gql`
    fragment CrosisContextCurrentUser on CurrentUser {
  id
  username
  isSubscribed
}
    `,n=r.gql`
    fragment CrosisContextRepl on Repl {
  id
  language
  slug
  user {
    id
    username
  }
  authorizations {
    editFileContents {
      isAuthorized
    }
  }
}
    `;e.s(["CrosisContextCurrentUserFragmentDoc",0,t,"CrosisContextReplFragmentDoc",0,n])},949791,e=>{"use strict";var r=e.i(351623);let t=r.gql`
    fragment AiProviderCurrentUser on CurrentUser {
  id
  timeCreated
}
    `;e.s(["AiProviderCurrentUserFragmentDoc",0,t])},575872,29530,663197,e=>{"use strict";var r=e.i(351623),t=e.i(344480);e.i(975473);var n=e.i(299020);let o={},i=r.gql`
    fragment WorkspaceDoGitProviderImportCurrentUser on CurrentUser {
  id
  username
}
    `,p=r.gql`
    fragment WorkspaceDoGitProviderImportRepl on Repl {
  id
  org {
    id
  }
  config {
    gitRemoteUrl
    doClone
    isAgentRepl
  }
  slug
}
    `,s=r.gql`
    query WorkspaceDoGitProviderImportFlow($replId: String!) {
  getRepl(id: $replId) {
    ...WorkspaceDoGitProviderImportRepl
  }
  currentUser {
    ...WorkspaceDoGitProviderImportCurrentUser
  }
}
    ${p}
${i}`,a=r.gql`
    mutation WorkspaceDoGitProviderImportFlowFinishClone($input: UpdateReplInput!) {
  updateRepl(input: $input) {
    repl {
      id
      config {
        doClone
      }
    }
  }
}
    `,u=r.gql`
    query GitHubImportGetTopLanguages($input: GitHubRepoInfoInput!) {
  githubRepoInfo(input: $input) {
    ... on GitHubRepoInfoOutput {
      topLanguages
      repositorySource
    }
    ... on TooManyRequestsError {
      message
    }
    ... on UnauthorizedError {
      message
    }
    ... on ServiceUnavailable {
      message
    }
    ... on UserError {
      message
    }
    ... on NotFoundError {
      message
    }
  }
}
    `,l=r.gql`
    query BitbucketImportGetTopLanguages($input: BitbucketRepoInfoInput!) {
  bitbucketRepoInfo(input: $input) {
    ... on BitbucketRepoInfoOutput {
      topLanguages
      repositorySource
    }
    ... on UnauthorizedError {
      message
    }
    ... on ServiceUnavailable {
      message
    }
    ... on UserError {
      message
    }
    ... on NotFoundError {
      message
    }
  }
}
    `;e.s(["WorkspaceDoGitProviderImportCurrentUserFragmentDoc",0,i,"WorkspaceDoGitProviderImportReplFragmentDoc",0,p,"useBitbucketImportGetTopLanguagesQuery",0,function(e){let r={...o,...e};return t.useQuery(l,r)},"useGitHubImportGetTopLanguagesQuery",0,function(e){let r={...o,...e};return t.useQuery(u,r)},"useWorkspaceDoGitProviderImportFlowFinishCloneMutation",0,function(e){let r={...o,...e};return n.useMutation(a,r)},"useWorkspaceDoGitProviderImportFlowQuery",0,function(e){let r={...o,...e};return t.useQuery(s,r)}],575872);let g=r.gql`
    fragment PageTitleRepl on Repl {
  id
  title
  project {
    id
    title
  }
}
    `;e.s(["PageTitleReplFragmentDoc",0,g],29530);let m=r.gql`
    fragment ReplInfoRepl on Repl {
  id
  title
  iconUrl
  project {
    id
  }
}
    `;e.s(["ReplInfoReplFragmentDoc",0,m],663197)},838317,e=>{"use strict";var r=e.i(351623),t=e.i(180273),n=e.i(669011),o=e.i(762288),i=e.i(85085),p=e.i(344480);e.i(975473);let s={},a=r.gql`
    fragment WorkspaceHeaderNavMenuRepl on Repl {
  id
  org {
    id
    slug
    ...IsUnifiedPlanEnabledOrg
  }
  ...ReplEnvironmentHeaderInviteButtonRepl
}
    ${t.IsUnifiedPlanEnabledOrgFragmentDoc}
${n.ReplEnvironmentHeaderInviteButtonReplFragmentDoc}`,u=r.gql`
    fragment WorkspaceHeaderNavMenuCurrentUser on CurrentUser {
  id
  image
  username
  ...IsUnifiedPlanEnabledPersonalWorkspaceCurrentUser
  ...UserLinkCurrentUser
  ...OrgSwitcherCurrentUser
}
    ${t.IsUnifiedPlanEnabledPersonalWorkspaceCurrentUserFragmentDoc}
${o.UserLinkCurrentUserFragmentDoc}
${i.OrgSwitcherCurrentUserFragmentDoc}`,l=r.gql`
    query WorkspaceHeaderNavMenu($replId: String!) {
  getRepl(id: $replId) {
    ... on Repl {
      ...WorkspaceHeaderNavMenuRepl
    }
  }
  currentUser {
    ...WorkspaceHeaderNavMenuCurrentUser
  }
}
    ${a}
${u}`;e.s(["WorkspaceHeaderNavMenuReplFragmentDoc",0,a,"useWorkspaceHeaderNavMenuQuery",0,function(e){let r={...s,...e};return p.useQuery(l,r)}])},951894,72159,879106,809541,e=>{"use strict";var r=e.i(351623),t=e.i(663197),n=e.i(669011),o=e.i(838317);let i=r.gql`
    fragment DesktopAppNavMenuRepl on Repl {
  ...WorkspaceHeaderNavMenuRepl
}
    ${o.WorkspaceHeaderNavMenuReplFragmentDoc}`,p=r.gql`
    fragment ReplEnvironmentHeaderRepl on Repl {
  id
  url
  agentFeedback {
    ... on ReplAgentFeedback {
      isEnabled
    }
  }
  authorizations {
    viewPermissions {
      isAuthorized
    }
    viewDeploymentConfig {
      isAuthorized
    }
    viewFreemiumExperience {
      isAuthorized
    }
  }
  owner {
    ... on Team {
      id
    }
    ... on User {
      id
      isSubscribed
    }
  }
  hostingDeployment {
    ... on HostingDeployment {
      id
      timeCreated
      replitAppSubdomain
      latestBuildStatus
      currentBuild {
        id
        provider
      }
    }
  }
  config {
    isInPlanningPhase
    isWebDesignMockup
  }
  isFreeUserWithStaticDeployment
  ...ReplInfoRepl
  ...ReplEnvironmentHeaderInviteButtonRepl
  ...DesktopAppNavMenuRepl
}
    ${t.ReplInfoReplFragmentDoc}
${n.ReplEnvironmentHeaderInviteButtonReplFragmentDoc}
${i}`;e.s(["ReplEnvironmentHeaderReplFragmentDoc",0,p],951894);var s=e.i(344480);e.i(975473);var a=e.i(299020);let u={},l=r.gql`
    fragment FigmaImportFlowRepl on Repl {
  id
  config {
    figmaUrl
    figmaImportStatus
  }
}
    `,g=r.gql`
    query FigmaImportFlow($replId: String!) {
  getRepl(id: $replId) {
    ... on Repl {
      id
      ...FigmaImportFlowRepl
    }
  }
}
    ${l}`,m=r.gql`
    mutation UpdateReplForFigmaImport($input: UpdateReplInput!) {
  updateRepl(input: $input) {
    repl {
      id
      isRenamed
      title
      ...FigmaImportFlowRepl
    }
  }
}
    ${l}`,d=r.gql`
    mutation GetFigmaIntermediateToken($input: GetFigmaIntermediateTokenInput!) {
  getFigmaIntermediateToken(input: $input) {
    ... on FigmaImportIntermediateToken {
      token
    }
    ... on NoOAuthFoundError {
      message
    }
    ... on InvalidFigmaUrlError {
      message
    }
    ... on FigmaRateLimitError {
      message
    }
  }
}
    `;e.s(["FigmaImportFlowReplFragmentDoc",0,l,"useFigmaImportFlowQuery",0,function(e){let r={...u,...e};return s.useQuery(g,r)},"useGetFigmaIntermediateTokenMutation",0,function(e){let r={...u,...e};return a.useMutation(d,r)},"useUpdateReplForFigmaImportMutation",0,function(e){let r={...u,...e};return a.useMutation(m,r)}],72159);var c=e.i(846545);let R={},I=r.gql`
    fragment LovableZipImportFlowRepl on Repl {
  id
  config {
    zipImportSource
    zipImportStatus
  }
}
    `,y=r.gql`
    query LovableZipImportFlow($replId: String!) {
  getRepl(id: $replId) {
    ... on Repl {
      id
      ...LovableZipImportFlowRepl
    }
  }
}
    ${I}`,O=r.gql`
    mutation UpdateReplForLovableZipImport($input: UpdateReplInput!) {
  updateRepl(input: $input) {
    repl {
      id
      ...LovableZipImportFlowRepl
    }
  }
}
    ${I}`,f=r.gql`
    subscription LovableImportZipProgress($replId: String!) {
  importZipProgress(replId: $replId)
}
    `;e.s(["LovableZipImportFlowReplFragmentDoc",0,I,"useLovableImportZipProgressSubscription",0,function(e){let r={...R,...e};return c.useSubscription(f,r)},"useLovableZipImportFlowQuery",0,function(e){let r={...R,...e};return s.useQuery(y,r)},"useUpdateReplForLovableZipImportMutation",0,function(e){let r={...R,...e};return a.useMutation(O,r)}],879106);let v=r.gql`
    fragment ReplEnvironmentDesktopTopLevelHooksRepl on Repl {
  id
  slug
  config {
    isAgentRepl
    isExpertMode
    isInPlanningPhase
  }
  org {
    id
  }
  origin {
    id
  }
  language
  user {
    id
    username
  }
  authorizations {
    editFileContents {
      isAuthorized
    }
  }
}
    `;e.s(["ReplEnvironmentDesktopTopLevelHooksReplFragmentDoc",0,v],809541)},689736,e=>{"use strict";var r=e.i(351623),t=e.i(319801),n=e.i(344480);e.i(975473);let o={},i=r.gql`
    fragment HandleReplRedirectionReplRedirect on ReplRedirect {
  replUrl
}
    `,p=r.gql`
    fragment HandleReplRedirectionSubscriptionExpired on ReplSubscriptionExpired {
  isOwner
  replId
}
    `,s=r.gql`
    fragment HandleReplRedirectionRepl on Repl {
  id
  isOwner
  language
  ...ReplLinkRepl
  authorizations {
    connectToWorkspace {
      isAuthorized
    }
  }
  org {
    id
  }
}
    ${t.ReplLinkReplFragmentDoc}`,a=r.gql`
    query HandleReplRedirection($replId: String!) {
  getRepl(id: $replId) {
    ... on Repl {
      ...HandleReplRedirectionRepl
      heliumMigrationStatus {
        isUsingHelium
        shouldMigrateToHelium
      }
    }
    ... on ReplRedirect {
      ...HandleReplRedirectionReplRedirect
    }
    ... on ReplSubscriptionExpired {
      ...HandleReplRedirectionSubscriptionExpired
    }
  }
}
    ${s}
${i}
${p}`;e.s(["HandleReplRedirectionReplFragmentDoc",0,s,"HandleReplRedirectionReplRedirectFragmentDoc",0,i,"HandleReplRedirectionSubscriptionExpiredFragmentDoc",0,p,"useHandleReplRedirectionQuery",0,function(e){let r={...o,...e};return n.useQuery(a,r)}])},966824,e=>{e.v({defaultText:"RecentReplsMenu-module__Zg4UXW__defaultText",recentReplsLabel:"RecentReplsMenu-module__Zg4UXW__recentReplsLabel",surfaceShades:"RecentReplsMenu-module__Zg4UXW__surfaceShades"})},345836,913864,280729,e=>{"use strict";var r=e.i(276385),t=e.i(389959),n=e.i(486597),o=e.i(624071),i=e.i(32988),p=e.i(351623),s=e.i(764992),a=e.i(575872),u=e.i(949791),l=e.i(180273),g=e.i(74768),m=e.i(29530),d=e.i(951894),c=e.i(117714),R=e.i(72159),I=e.i(879106),y=e.i(809541),O=e.i(689736);let f=p.gql`
    fragment ReplEnvironmentDesktopCurrentUser on CurrentUser {
  id
  isAdmin: hasRole(role: ADMIN)
  ...CrosisContextCurrentUser
  workspacePreferences
  ...WorkspaceDoGitProviderImportCurrentUser
  ...AiProviderCurrentUser
  ...IsUnifiedPlanEnabledPersonalWorkspaceCurrentUser
}
    ${s.CrosisContextCurrentUserFragmentDoc}
${a.WorkspaceDoGitProviderImportCurrentUserFragmentDoc}
${u.AiProviderCurrentUserFragmentDoc}
${l.IsUnifiedPlanEnabledPersonalWorkspaceCurrentUserFragmentDoc}`,v=p.gql`
    fragment ReplAiAuthorizations on ReplAuthorizations {
  useAdvancedChat: useAiChat(model: advanced) {
    isAuthorized
    code
    message
  }
  connectToWorkspace {
    isAuthorized
    code
  }
}
    `,S=p.gql`
    fragment ReplEnvironmentDesktopRepl on Repl {
  id
  title
  layoutState
  description
  url
  origin {
    id
  }
  org {
    ...IsUnifiedPlanEnabledOrg
  }
  config {
    isAgentStack
    isInPlanningPhase
    figmaUrl
    ...ReplAgentSettingsReplConfig
  }
  ...CrosisContextRepl
  ...PageTitleRepl
  authorizations {
    ...ReplAiAuthorizations
  }
  ...WorkspaceDoGitProviderImportRepl
  ...ReplEnvironmentHeaderRepl
  ...NewPaneRepl
  ...FigmaImportFlowRepl
  ...LovableZipImportFlowRepl
  ...ReplEnvironmentDesktopTopLevelHooksRepl
  ...HandleReplRedirectionRepl
}
    ${l.IsUnifiedPlanEnabledOrgFragmentDoc}
${g.ReplAgentSettingsReplConfigFragmentDoc}
${s.CrosisContextReplFragmentDoc}
${m.PageTitleReplFragmentDoc}
${v}
${a.WorkspaceDoGitProviderImportReplFragmentDoc}
${d.ReplEnvironmentHeaderReplFragmentDoc}
${c.NewPaneReplFragmentDoc}
${R.FigmaImportFlowReplFragmentDoc}
${I.LovableZipImportFlowReplFragmentDoc}
${y.ReplEnvironmentDesktopTopLevelHooksReplFragmentDoc}
${O.HandleReplRedirectionReplFragmentDoc}`;e.s(["ReplAiAuthorizationsFragmentDoc",0,v,"ReplEnvironmentDesktopCurrentUserFragmentDoc",0,f,"ReplEnvironmentDesktopReplFragmentDoc",0,S],913864);var $=e.i(344480);e.i(975473);let F={},_=p.gql`
    fragment SidebarRecentRepl on Repl {
  id
  title
  iconUrl
  url
  nextPagePathname
  ...ReplEnvironmentDesktopRepl
}
    ${S}`,G=p.gql`
    query SidebarRecentRepls($count: Int!) {
  allRecentRepls: recentRepls(count: $count) {
    id
    ...SidebarRecentRepl
  }
}
    ${_}`;function D(e){let r={...F,...e};return $.useQuery(G,r)}let P=p.gql`
    query SidebarRecentOrgRepls($count: Int!, $orgId: String) {
  currentUser {
    id
    org(orgId: $orgId) {
      ... on Org {
        id
        recentRepls(input: {count: $count}) {
          items {
            id
            ...SidebarRecentRepl
          }
        }
      }
      ... on Error {
        message
      }
    }
  }
}
    ${_}`;function C(e){let r={...F,...e};return $.useQuery(P,r)}e.s(["useSidebarRecentOrgReplsQuery",0,C,"useSidebarRecentReplsQuery",0,D],280729);var E=e.i(269848),U=e.i(761201),b=e.i(780902);e.i(214847);var h=e.i(864300),q=e.i(127384),M=e.i(919073),k=e.i(295231),A=e.i(798142),x=e.i(8047),H=e.i(61732),w=e.i(921125),N=e.i(365757),L=e.i(966824);let T=({repl:e})=>{let t=(0,w.replLinkProps)(e);return(0,r.jsx)(k.MenuItem,{icon:(0,r.jsx)(N.default,{size:16,iconUrl:e.iconUrl,alt:e.title}),label:e.title,href:t.href,as:t.as})},z=({loading:e,recentRepls:t})=>{let n=(0,h.useIntl)(),o=n.formatMessage(U.REPL_DISPLAY_NAME.plural),i=e&&!t?.length?(0,r.jsx)(H.View,{grow:!0,justify:"center",align:"center",children:(0,r.jsx)(E.default,{})}):(0,r.jsx)(r.Fragment,{children:t?.length?(0,r.jsxs)(r.Fragment,{children:[(0,r.jsxs)(x.Text,{multiline:!1,variant:"small",color:"dimmer",clsx:L.default.recentReplsLabel,children:["Recent ",o]}),(0,r.jsx)(k.Menu,{"aria-label":`Recent ${o}`,children:t.map(e=>(0,r.jsx)(T,{repl:e},e.id))})]}):(0,r.jsx)(H.View,{grow:!0,justify:"center",align:"center",children:(0,r.jsx)(x.Text,{variant:"small",color:"dimmer",clsx:L.default.defaultText,children:n.formatMessage({id:"home.recentlyViewedEntities",defaultMessage:"Recently viewed {entityName} will show up here"},{entityName:o})})})});return(0,r.jsx)(M.ShadesSurface,{colorShade:"themePopup",border:"regular",p:4,br:6,clsx:L.default.surfaceShades,children:i})},W=(e,r)=>{if(!r)return!1;let{clientX:t,clientY:n}=e,{left:o,right:i,top:p,bottom:s}=r.getBoundingClientRect();return t>=o&&t<=i&&n>=p&&n<=s};e.s(["OrgSidebarRecentRepls",0,({orgId:e})=>{let{data:t,loading:n}=C({variables:{count:6,orgId:e},ssr:!1,fetchPolicy:"cache-and-network",nextFetchPolicy:"cache-first"}),o=t?.currentUser?.org?.__typename==="Org"?t?.currentUser?.org?.recentRepls.items:void 0;return(0,r.jsx)(z,{loading:n,recentRepls:o})},"RECENT_REPLS_SIDEBAR_MENU_COUNT",0,6,"RecentReplsPopover",0,({children:e})=>{let{setTriggerElement:p,setPopoverElement:s,styles:a,attributes:u,triggerElement:l,popoverElement:g}=(()=>{let[e,r]=(0,t.useState)(null),[n,o]=(0,t.useState)(null),{styles:p,attributes:s}=(0,i.usePopper)(e,n,{modifiers:[{name:"offset",options:{offset:[0,4]}}],placement:"right-start"});return{setTriggerElement:r,setPopoverElement:o,styles:p.popper,attributes:s.popper,triggerElement:e,popoverElement:n}})(),m=(0,n.useOverlayTriggerState)({}),d=(({setOpen:e,timeout:r=200,triggerElement:n,popoverElement:o})=>{let i=(0,t.useRef)(null),p=(0,t.useRef)(!0);return(0,t.useEffect)(()=>{let e=e=>{n&&(p.current=!W(e,n)),r()},r=()=>{document.body.removeEventListener("mouseenter",e)};return document.body.addEventListener("mouseenter",e),r},[n]),{onMouseMove:(0,t.useCallback)(()=>{p.current&&(e(!0),i.current&&clearTimeout(i.current))},[e]),onMouseLeave:(0,t.useCallback)(t=>{i.current&&clearTimeout(i.current),p.current=!0,W(t,o)||(i.current=setTimeout(()=>{e(!1)},r))},[e,r,o])}})({setOpen:m.setOpen,popoverElement:g,triggerElement:l}),[c,R]=e,I=(0,b.useIsMobile)();return(0,r.jsxs)(r.Fragment,{children:[c(d,p),m.isOpen&&!I&&(0,r.jsx)(A.Portal,{children:(0,r.jsx)("div",{"aria-hidden":!0,ref:s,style:{...a,zIndex:q.SIDEBAR_Z_INDEX},...(0,o.mergeProps)(u,d),children:R})})]})},"SidebarRecentRepls",0,()=>{let{data:e,loading:t}=D({variables:{count:6},ssr:!1,fetchPolicy:"cache-and-network",nextFetchPolicy:"cache-first"});return(0,r.jsx)(z,{loading:t,recentRepls:e?.allRecentRepls})}],345836)}]);

//# debugId=c1308f7b-58a9-14e6-227c-748c75726bb0
//# sourceMappingURL=04.0k44emrz36.js.map