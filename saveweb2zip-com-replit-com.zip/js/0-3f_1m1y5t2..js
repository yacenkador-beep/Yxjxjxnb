;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="a58e0c8a-987b-f156-c6e7-1884aa0550e6")}catch(e){}}();
(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,228290,e=>{e.v({container:"index-module__z1kyYa__container",menu:"index-module__z1kyYa__menu",notificationIndicator:"index-module__z1kyYa__notificationIndicator",popover:"index-module__z1kyYa__popover"})},237671,980224,e=>{"use strict";var t=e.i(276385),i=e.i(389959),n=e.i(532764),o=e.i(351623),a=e.i(344480);e.i(975473);var r=e.i(846545);let l={},s=o.gql`
    query notificationCount {
  currentUser {
    id
    notificationCount
  }
}
    `,c=o.gql`
    subscription notificationCountChanges {
  notificationCount
}
    `;function u(){var e;let t,n,{data:o,refetch:u,client:d}=(t={...l,...void 0},a.useQuery(s,t)),m=(0,i.useCallback)(e=>{o?.currentUser&&d.writeQuery({query:s,data:{...o,currentUser:{...o.currentUser,notificationCount:e}}})},[o?.currentUser?.id]);return e={onData:({data:{data:e}})=>{"number"==typeof e?.notificationCount&&m(e.notificationCount)}},n={...l,...e},r.useSubscription(c,n),{count:Math.max(0,o?.currentUser?.notificationCount||0),refetch:u,setUnreadCount:m}}e.s(["default",0,u],980224);var d=e.i(488299),m=e.i(773222),f=e.i(61732),p=e.i(228290);e.s(["NavMenu",0,function(e){let[o,a]=(0,i.useState)(!1),{count:r}=u();return(0,t.jsxs)(f.View,{clsx:p.default.container,children:[(0,t.jsxs)(m.PopoverTrigger,{isOpen:o,onOpenChange:t=>{a(t),e.onOpenChange?.(t)},label:"Menu",placement:"bottom start",clsx:p.default.popover,offset:2,containerPadding:2,children:[(0,t.jsx)(d.IconButton,{alt:"Menu",size:28,tooltipBehavior:"hidden",children:(0,t.jsx)(n.default,{})}),(0,t.jsx)(f.View,{p:4,clsx:p.default.menu,br:6,children:"function"==typeof e.children?e.children(()=>a(!1)):e.children})]}),r>0?(0,t.jsx)(f.View,{clsx:p.default.notificationIndicator}):null]})}],237671)},841114,e=>{"use strict";var t=e.i(351623),i=e.i(344480);e.i(975473);var n=e.i(299020);let o={},a=t.gql`
    query ThemePreferenceCurrentUser {
  currentUser {
    id
    workspacePreferences
  }
}
    `,r=t.gql`
    mutation ThemePreferenceUpdate($input: JSON!) {
  updateWorkspacePreferences(input: $input) {
    id
    workspacePreferences
  }
}
    `;var l=e.i(320216);e.s(["useThemePreference",0,function(){var e;let t,s,{showError:c}=(0,l.default)(),{data:u}=(e={ssr:!0},t={...o,...e},i.useQuery(a,t)),d=u?.currentUser?.__typename==="CurrentUser"?u.currentUser:null,m=d?.workspacePreferences.theme,f=null==m,[p]=(s={...o,...void 0},n.useMutation(r,s)),x=async e=>{if(!d)return;let t="system"===e?null:e;null===t&&f||(t!==m||f)&&await p({variables:{input:{theme:t}},optimisticResponse:{__typename:"RootMutationType",updateWorkspacePreferences:{__typename:"CurrentUser",id:d.id,workspacePreferences:{...d.workspacePreferences,theme:t}}},onError:()=>c("Something went wrong setting the active theme - please try again.")})};return{isSystemTheme:f,setActiveTheme:x}}],841114)},636562,e=>{e.v({container:"index-module__LUcORa__container",flexButtons:"index-module__LUcORa__flexButtons",frontFormSection:"index-module__LUcORa__frontFormSection",subcategorySection:"index-module__LUcORa__subcategorySection"})},64017,e=>{"use strict";var t=e.i(276385),i=e.i(389959),n=e.i(351623),o=e.i(344480);e.i(975473);let a={},r=n.gql`
    query currentUser {
  currentUser {
    __typename
    id
    username
    isSubscribed
    isMemberOfAnyOrg
  }
}
    `;var l=e.i(787527),s=e.i(252204),c=e.i(295652),u=e.i(612343),d=e.i(596139),m=e.i(3466),f=e.i(316431),p=e.i(419635),x=e.i(108431),h=e.i(8047),g=e.i(61732),N=e.i(908796);let j=[{value:"billing-issue",title:"Billing",showFrontForm:!0},{value:"account-issue",title:"Account",showFrontForm:!0},{value:"technical-issue",title:"Technical",showFrontForm:!0}];var y=e.i(299020);let v={},C=n.gql`
    mutation frontSupportRequest($input: FrontSupportRequestInput!) {
  frontSupportRequest(input: $input) {
    ... on UserError {
      message
    }
    ... on TooManyRequestsError {
      message
    }
    ... on UnauthorizedError {
      message
    }
    ... on FrontSupportRequestSuccess {
      success
    }
    __typename
  }
}
    `;var I=N,_=e.i(269848),w=e.i(320216),b=e.i(415541),k=e.i(709485),S=e.i(643484),T=e.i(528710);let R={},M=n.gql`
    fragment ReplSelectorRepl on Repl {
  id
  title
  timeUpdated
  url
  slug
  owner {
    ... on User {
      id
      username
      image
      fullName
    }
    ... on Team {
      id
      username
      image
    }
  }
  iconUrl
  templateLabel
  publishedAs
}
    `,L=n.gql`
    query ReplSelector($search: String!, $excludePrivate: Boolean, $excludeMultiplayer: Boolean) {
  currentUser {
    id
    replSearch(
      search: $search
      excludePrivate: $excludePrivate
      excludeMultiplayer: $excludeMultiplayer
    ) {
      id
      ...ReplSelectorRepl
    }
  }
}
    ${M}`;var A=e.i(602686),$=e.i(619158),O=e.i(480028),P=e.i(760982),U=e.i(585544),q=e.i(365757);let B="__not_app_specific__",F="Not related to a specific app";function V(e){return e.owner?`${e.owner.username}/${e.title}`:e.title}function E({onSelect:e}){var n;let a,[r,l]=(0,i.useState)(""),[s,c]=(0,i.useState)(null),u=(0,i.useRef)([]),d=(0,$.default)(r,150),m=u.current.find(e=>e.id===s),f=""===r?"":d,{data:p,loading:x}=(n={variables:{search:s&&m&&f===V(m)?"":f,excludeMultiplayer:!1}},a={...R,...n},o.useQuery(L,a)),N=p?.currentUser?.replSearch??[];return u.current=N,(0,t.jsxs)(P.ComboBox,{"aria-label":"Select an app",placeholder:"Select an app",menuTrigger:"focus",style:{width:"100%"},selectedKey:s,inputValue:r,onInputChange:t=>{if(l(t),s&&s!==B){let i=u.current.find(e=>e.id===s);i&&t===V(i)||(c(null),e(null))}else s===B&&t!==F&&(c(null),e(null))},triggerIcon:s?(0,t.jsx)(A.default,{}):void 0,triggerButtonProps:s?{onClick:()=>{c(null),l(""),e(null)}}:void 0,isLoading:x&&0===N.length,emptyMessage:"No apps found",maxHeight:240,onSelectionChange:t=>{if(c(t),null===t)return void e(null);if(t===B){e("none"),l(F);return}let i=u.current.find(e=>e.id===t);i&&(e(i),l(V(i)))},children:[(0,t.jsx)(U.BaseListBoxItem,{id:B,textValue:F,children:(0,t.jsx)(h.Text,{color:"dimmer",multiline:!1,children:F})},B),N.map(e=>(0,t.jsx)(U.BaseListBoxItem,{id:e.id,textValue:V(e),children:(0,t.jsxs)(g.View,{row:!0,gap:8,align:"center",children:[e.iconUrl?(0,t.jsx)(q.default,{alt:e.title,iconUrl:e.iconUrl,size:16}):null,(0,t.jsx)(g.View,{row:!0,align:"center",children:e.owner?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("span",{style:{color:O.tokens.greyDimmer},children:[e.owner.username,"/"]}),(0,t.jsx)("span",{children:e.title})]}):(0,t.jsx)("span",{children:e.title})})]})},e.id))]})}let z=({onDone:e,type:n,subcategory:o,config:a={titleField:"Subject",titleDescription:"Briefly describe what's going on",titlePlaceholder:"I am unable to...",bodyField:"Description",bodyDescription:"Please detail what you're experiencing, and any additional information that can help us help you.",bodyPlaceholder:"I am currently experiencing...",allowAttachments:!0},categoryType:r=I.SupportCategoryType.AccountBilling})=>{var l;let s,c=r===I.SupportCategoryType.Technical,{showError:u,showConfirm:d}=(0,w.default)(),[m,f]=(0,i.useState)(""),[p,x]=(0,i.useState)(""),[N,j]=(0,i.useState)(null);(0,i.useEffect)(()=>{j(null)},[r]);let[R,{loading:M}]=(l={onError:e=>{u(e.toString())},onCompleted:t=>{e(),"FrontSupportRequestSuccess"===t.frontSupportRequest.__typename?d("Your message was successfully sent. We will be in touch via email shortly."):u(t.frontSupportRequest.message)}},s={...v,...l},y.useMutation(C,s));return(0,t.jsxs)(g.View,{gap:16,style:{minWidth:0},children:[c?(0,t.jsxs)(g.View,{gap:8,children:[(0,t.jsx)(h.Text,{variant:"subheadDefault",multiline:!1,children:"App name"}),(0,t.jsx)(E,{onSelect:j})]}):null,a.titleField?(0,t.jsxs)(g.View,{gap:8,children:[(0,t.jsx)(h.Text,{variant:"subheadDefault",multiline:!1,children:a.titleField}),(0,t.jsx)(T.Input,{value:m,onChange:e=>f(e.target.value),placeholder:a.titleDescription??a.titlePlaceholder})]}):null,(0,t.jsxs)(g.View,{gap:8,children:[a.bodyField?(0,t.jsx)(h.Text,{variant:"subheadDefault",multiline:!1,children:a.bodyField}):null,(0,t.jsx)(T.MultiLineInput,{style:{width:"100%",boxSizing:"border-box"},value:p,onChange:e=>x(e.target.value),placeholder:c?"What's happening? Include steps to reproduce and any error messages you're seeing.\n\n1. Go to...\n2. Click on...\n3. See error...":a.bodyDescription??a.bodyPlaceholder,rows:6})]}),(0,t.jsxs)(g.View,{row:!0,gap:4,justify:"end",children:[(0,t.jsx)(S.Button,{text:"Cancel",onClick:e}),(0,t.jsx)(S.Button,{text:"Submit",onClick:()=>{let e=a.titleField&&m.length>3,t=p.length>20,i=!c||null!==N,l="none"!==N?N:null;if(!e||!t||!i){let n=[];i||n.push("Please select an app"),e||n.push("Subject must be at least 3 characters"),t||n.push("Description must be at least 20 characters"),u(n.join(". ")+".");return}let s=l?.title,d=l?.id;R({variables:{input:{title:m,body:[p,c&&s?`

App Name: ${s}`:""].join(""),type:r,replId:c?d||"N/A":void 0,clientInformation:{pageUrl:location.href,browser:window.navigator.userAgent}}}}),(0,b.track)(k.events.HELP_FORM_SUBMITTED,{category:n,subcategory:o})},colorway:"primary",loading:M,iconLeft:M?(0,t.jsx)(_.default,{}):void 0})]})]})};var D=e.i(636562);e.s(["default",0,({onRequestClose:e,items:n,initialOptionPlaceholder:y="Choose an option",formConfig:v})=>{let C,[I,_]=(0,i.useState)(null),[w,b]=(0,i.useState)(null),{data:k,loading:S}=(C={...a,...void 0},o.useQuery(r,C)),T=k?.currentUser?.isSubscribed,R=k?.currentUser?.isMemberOfAnyOrg;(0,i.useEffect)(()=>{I?.subcategories&&b(I.subcategories[0])},[I]);let M=(0,i.useMemo)(()=>n||(T||R?j:[]),[n,T,R]),L=!!I&&(I.showFrontForm||!!w?.showFrontForm),A=16*!!L;return(0,t.jsxs)(g.View,{clsx:D.default.container,children:[M.length>0?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(h.Text,{variant:"subheadDefault",multiline:!1,children:"Get help"}),(0,t.jsx)(x.StatusBanner,{colorway:"primary",text:`Hi there, ${S?"":k?.currentUser?.username+"!"} How can we help?`}),(0,t.jsx)(f.Select,{"aria-label":"Select support category",items:M,selectedItem:I,onChange:e=>_(e),placeholder:y}),null!==I?(0,t.jsxs)(g.View,{children:[(0,t.jsx)(g.View,{pb:A,gap:8}),I.subcategories?.length&&w?(0,t.jsx)(g.View,{clsx:D.default.subcategorySection,pb:A,pt:16,gap:8,children:(0,t.jsx)(f.Select,{"aria-label":"Select subcategory",items:I.subcategories,selectedItem:w,onChange:e=>b(e)})}):null,L?(0,t.jsx)(g.View,{clsx:D.default.frontFormSection,pt:16,children:(0,t.jsx)(z,{onDone:e,type:I.value,config:v,categoryType:function(e){switch(e){case"billing-issue":return N.SupportCategoryType.Billing;case"account-issue":return N.SupportCategoryType.Account;case"technical-issue":return N.SupportCategoryType.Technical;default:return}}(I.value)})}):null]}):null]}):(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(h.Text,{variant:"subheadBig",multiline:!1,children:"Subscription is required for Support"}),(0,t.jsx)(m.default,{context:"support_dialog",text:`Upgrade to Replit ${d.corePlanName}`,colorway:"primary"})]}),(0,t.jsxs)(g.View,{clsx:D.default.flexButtons,pt:16,row:!0,gap:8,children:[(0,t.jsx)(p.ButtonLink,{href:"https://docs.replit.com/legal-and-security-info/abuse-report",target:"_blank",text:"Report abuse",iconRight:(0,t.jsx)(s.default,{}),iconLeft:(0,t.jsx)(c.default,{}),size:"small"}),(0,t.jsx)(p.ButtonLink,{href:"https://docs.replit.com",target:"_blank",text:"Read the docs",iconRight:(0,t.jsx)(s.default,{}),iconLeft:(0,t.jsx)(l.default,{}),size:"small"}),(0,t.jsx)(p.ButtonLink,{href:"https://replit.com/community",target:"_blank",text:"Check the community",iconRight:(0,t.jsx)(s.default,{}),iconLeft:(0,t.jsx)(u.default,{}),size:"small"})]})]})}],64017)},987987,e=>{e.v({content:"Item-module__2hGgkG__content",contentContainer:"Item-module__2hGgkG__contentContainer",itemText:"Item-module__2hGgkG__itemText",itemTextNewFollowerWrapper:"Item-module__2hGgkG__itemTextNewFollowerWrapper",userAvatarLink:"Item-module__2hGgkG__userAvatarLink",usernameLink:"Item-module__2hGgkG__usernameLink"})},413325,e=>{e.v({buttonGroupContainer:"List-module__a4KWka__buttonGroupContainer",compact:"List-module__a4KWka__compact",emptyState:"List-module__a4KWka__emptyState",emptyStateContainer:"List-module__a4KWka__emptyStateContainer",list:"List-module__a4KWka__list",loadMoreContainer:"List-module__a4KWka__loadMoreContainer",textCenter:"List-module__a4KWka__textCenter"})},638046,e=>{e.v({count:"NotificationsItem-module__00pi2G__count"})},286093,765185,736372,556278,566032,e=>{"use strict";var t=e.i(276385),i=e.i(389959),n=e.i(351623);let o=n.gql`
    fragment NotificationItemCreator on User {
  id
  image
  username
  fullName
  url
}
    `,a=n.gql`
    fragment NotificationItemRepliedToPostNotification on RepliedToPostNotification {
  id
  text
  url
  timeCreated
  seen
  creator {
    id
    ...NotificationItemCreator
  }
}
    ${o}`,r=n.gql`
    fragment NotificationItemRepliedToCommentNotification on RepliedToCommentNotification {
  id
  text
  url
  timeCreated
  seen
  creator {
    id
    ...NotificationItemCreator
  }
}
    ${o}`,l=n.gql`
    fragment NotificationItemMentionedInPostNotification on MentionedInPostNotification {
  id
  text
  url
  timeCreated
  seen
  creator {
    id
    ...NotificationItemCreator
  }
}
    ${o}`,s=n.gql`
    fragment NotificationItemMentionedInCommentNotification on MentionedInCommentNotification {
  id
  text
  url
  timeCreated
  seen
  creator {
    id
    ...NotificationItemCreator
  }
}
    ${o}`,c=n.gql`
    fragment NotificationItemAnswerAcceptedNotification on AnswerAcceptedNotification {
  id
  text
  url
  timeCreated
  seen
  creator {
    id
    ...NotificationItemCreator
  }
}
    ${o}`,u=n.gql`
    fragment NotificationItemMultiplayerJoinedEmailNotification on MultiplayerJoinedEmailNotification {
  id
  text
  url
  timeCreated
  seen
  creator {
    id
    ...NotificationItemCreator
  }
}
    ${o}`,d=n.gql`
    fragment NotificationItemMultiplayerJoinedLinkNotification on MultiplayerJoinedLinkNotification {
  id
  text
  url
  timeCreated
  seen
  creator {
    id
    ...NotificationItemCreator
  }
}
    ${o}`,m=n.gql`
    fragment NotificationItemMultiplayerInvitedNotification on MultiplayerInvitedNotification {
  id
  text
  url
  timeCreated
  seen
  creator {
    id
    ...NotificationItemCreator
  }
}
    ${o}`,f=n.gql`
    fragment NotificationItemMultiplayerOverlimitNotification on MultiplayerOverlimitNotification {
  id
  text
  url
  timeCreated
  seen
  creator {
    id
    ...NotificationItemCreator
  }
}
    ${o}`,p=n.gql`
    fragment NotificationItemWarningNotification on WarningNotification {
  id
  text
  url
  timeCreated
  seen
}
    `,x=n.gql`
    fragment NotificationItemTeamInvite on TeamInvite {
  id
  team {
    id
    displayName
    username
  }
}
    `,h=n.gql`
    fragment NotificationItemTeamInviteNotification on TeamInviteNotification {
  id
  text
  url
  timeCreated
  seen
  invite {
    id
    ...NotificationItemTeamInvite
  }
}
    ${x}`,g=n.gql`
    fragment NotificationItemTeamOrganizationInvite on TeamOrganizationInvite {
  id
  organization {
    id
    name
  }
}
    `,N=n.gql`
    fragment NotificationItemTeamOrganizationInviteNotification on TeamOrganizationInviteNotification {
  id
  text
  url
  timeCreated
  seen
  invite {
    id
    ...NotificationItemTeamOrganizationInvite
  }
}
    ${g}`,j=n.gql`
    fragment NotificationTeamTemplateSubmittedNotification on TeamTemplateSubmittedNotification {
  id
  text
  url
  timeCreated
  seen
  repl {
    id
    url
  }
}
    `,y=n.gql`
    fragment NotificationTeamTemplateReviewedStatusNotification on TeamTemplateReviewedStatusNotification {
  id
  text
  url
  timeCreated
  seen
  repl {
    id
    url
  }
}
    `,v=n.gql`
    fragment NotificationReplCommentCreatedNotification on ReplCommentCreatedNotification {
  id
  url
  timeCreated
  seen
  creator {
    id
    ...NotificationItemCreator
  }
}
    ${o}`,C=n.gql`
    fragment NotificationReplCommentReplyCreatedNotification on ReplCommentReplyCreatedNotification {
  id
  timeCreated
  seen
  creator {
    id
    ...NotificationItemCreator
  }
}
    ${o}`,I=n.gql`
    fragment NotificationReplCommentMentionNotification on ReplCommentMentionNotification {
  id
  timeCreated
  seen
  creator {
    id
    ...NotificationItemCreator
  }
}
    ${o}`,_=n.gql`
    fragment NotificationItemNewFollower on NewFollowerNotification {
  id
  timeCreated
  seen
  url
  creator {
    ...NotificationItemCreator
  }
}
    ${o}`,w=n.gql`
    fragment BasicNotificationItemNotification on BasicNotification {
  id
  text
  url
  timeCreated
  seen
  context
}
    `,b=n.gql`
    fragment NotificationItemEgressLimitNotification on EgressLimitNotification {
  id
  url
  timeCreated
  seen
  variant
  limitGib
  percentage
}
    `,k=n.gql`
    fragment NotificationItemOrgUpgradeRequestReviewedNotification on OrgUpgradeRequestReviewedNotification {
  id
  timeCreated
  seen
  url
  creator {
    ...NotificationItemCreator
  }
  isAccepted
  orgId
}
    ${o}`;var S=e.i(344480);e.i(975473);let T={},R=n.gql`
    fragment NotificationItems on Notification {
  ... on BasicNotification {
    id
    ...BasicNotificationItemNotification
  }
  ... on MentionedInPostNotification {
    id
    ...NotificationItemMentionedInPostNotification
  }
  ... on RepliedToPostNotification {
    id
    ...NotificationItemRepliedToPostNotification
  }
  ... on MentionedInCommentNotification {
    id
    ...NotificationItemMentionedInCommentNotification
  }
  ... on RepliedToCommentNotification {
    id
    ...NotificationItemRepliedToCommentNotification
  }
  ... on AnswerAcceptedNotification {
    id
    ...NotificationItemAnswerAcceptedNotification
  }
  ... on MultiplayerInvitedNotification {
    id
    ...NotificationItemMultiplayerInvitedNotification
  }
  ... on MultiplayerJoinedEmailNotification {
    id
    ...NotificationItemMultiplayerJoinedEmailNotification
  }
  ... on MultiplayerJoinedLinkNotification {
    id
    ...NotificationItemMultiplayerJoinedLinkNotification
  }
  ... on MultiplayerOverlimitNotification {
    id
    ...NotificationItemMultiplayerOverlimitNotification
  }
  ... on WarningNotification {
    id
    ...NotificationItemWarningNotification
  }
  ... on TeamInviteNotification {
    id
    ...NotificationItemTeamInviteNotification
  }
  ... on TeamOrganizationInviteNotification {
    id
    ...NotificationItemTeamOrganizationInviteNotification
  }
  ... on TeamTemplateSubmittedNotification {
    id
    ...NotificationTeamTemplateSubmittedNotification
  }
  ... on TeamTemplateReviewedStatusNotification {
    id
    ...NotificationTeamTemplateReviewedStatusNotification
  }
  ... on ReplCommentCreatedNotification {
    id
    ...NotificationReplCommentCreatedNotification
  }
  ... on ReplCommentReplyCreatedNotification {
    id
    ...NotificationReplCommentReplyCreatedNotification
  }
  ... on ReplCommentMentionNotification {
    id
    ...NotificationReplCommentMentionNotification
  }
  ... on NewFollowerNotification {
    id
    ...NotificationItemNewFollower
  }
  ... on OrgUpgradeRequestReviewedNotification {
    id
    ...NotificationItemOrgUpgradeRequestReviewedNotification
  }
  ... on EgressLimitNotification {
    id
    ...NotificationItemEgressLimitNotification
  }
  ... on OrgUpgradeRequestReviewedNotification {
    id
    ...NotificationItemOrgUpgradeRequestReviewedNotification
  }
}
    ${w}
${l}
${a}
${s}
${r}
${c}
${m}
${u}
${d}
${f}
${p}
${h}
${N}
${j}
${y}
${v}
${C}
${I}
${_}
${k}
${b}`,M=n.gql`
    query notifications($after: String, $count: Int, $seen: Boolean) {
  currentUser {
    id
  }
  notifications(after: $after, count: $count, seen: $seen) {
    items {
      ...NotificationItems
    }
    pageInfo {
      nextCursor
    }
  }
}
    ${R}`;var L=e.i(299020);let A={},$=n.gql`
    mutation MarkAllNotificationsAsSeen {
  markAllNotificationsAsSeen {
    id
    notificationCount
  }
}
    `;var O=e.i(183035),P=e.i(269848),U=e.i(638424),q=e.i(927600),B=e.i(415541),F=e.i(709485),V=e.i(480028),E=e.i(462229),z=e.i(723517),D=e.i(691636);let W=(0,E.cssRecord)({root:[D.rcss.display.flex,D.rcss.align.center,D.rcss.p(12),{'&[data-has-link="true"]':[{pointerEvents:"none","a, button":{pointerEvents:"all"}}],'&[data-last-item="true"]':[D.rcss.border({width:1,color:V.tokens.outlineDimmest,direction:"bottom"})]}],notificationLinkWrapper:[[{borderWidth:0,":nth-last-child(2)>a":{borderBottomLeftRadius:V.tokens.space8,borderBottomRightRadius:V.tokens.space8,"::after":{borderBottomLeftRadius:V.tokens.space8,borderBottomRightRadius:V.tokens.space8}}}]],notificationLink:[z.interactive.listItem,D.rcss.color.foregroundDefault,D.rcss.display.block,D.rcss.focusRingOnAfter,D.rcss.position.relative,{":focus-visible":{boxShadow:"none !important"},"::after":{content:'""',position:"absolute",top:0,right:0,bottom:0,left:0,display:"block",zIndex:1}}],content:[D.rcss.flex.grow(1),D.rcss.pr(12)],indicatorLink:[D.rcss.display.flex,D.rcss.align.center],indicator:[D.rcss.width(6),D.rcss.height(6),D.rcss.backgroundColor.blueStronger,D.rcss.borderRadius("full"),D.rcss.mr(2)]}),G=({condition:e,children:t,wrap:n})=>e?(0,i.cloneElement)(n(t)):t;function H({children:e,seen:i,href:n,as:o,isLastItem:a=!1}){let r=!!(n||o);return(0,t.jsx)(G,{condition:r,wrap:e=>(0,t.jsxs)("div",{css:W.notificationLinkWrapper,children:[o&&n?(0,t.jsx)(U.default,{as:o,href:n,css:W.notificationLink,children:e}):null,!o&&n&&"object"==typeof n?(0,t.jsx)(U.default,{href:n,css:W.notificationLink,children:e}):null,o||"string"!=typeof n?null:(0,t.jsx)("a",{css:W.notificationLink,href:n,children:e})]}),children:(0,t.jsxs)("div",{onClick:()=>{r&&(0,B.track)(F.events.NOTIFICATION_ITEM_CLICKED,{seen:i})},css:W.root,"data-has-link":r,"data-last-item":a,children:[(0,t.jsx)("div",{css:W.content,children:e}),r?(0,t.jsxs)("div",{css:W.indicatorLink,children:[!i&&(0,t.jsx)("div",{css:W.indicator}),(0,t.jsx)(q.default,{color:V.tokens.foregroundDimmest})]}):null]})})}var K=e.i(192915),Y=e.i(825419),J=e.i(8047),Q=e.i(472499),X=e.i(61732),Z=e.i(987987);let ee=({seen:e,url:i,as:n,href:o,text:a,timeCreated:r,creator:l,invite:s,orgInvite:c,isLastItem:u=!1,...d})=>{let m,f;return i&&((m=new URL("/"===i[0]?`https://replit.com${i}`:i)).searchParams.set("from","notifications"),f=(i.startsWith("http")&&"https:"===m.protocol?m.protocol+"//"+m.hostname:"")+m.pathname+m.search+m.hash),(0,t.jsx)(H,{seen:e,compact:d.compact,isLastItem:u,as:n,href:o||f,children:(0,t.jsxs)("div",{clsx:Z.default.contentContainer,children:[l?(0,t.jsx)(U.default,{...(0,K.userLinkProps)(l),clsx:Z.default.userAvatarLink,children:(0,t.jsx)(Y.Avatar,{size:32,src:l.image,username:l.username,fullName:l.fullName})}):null,(0,t.jsxs)(X.View,{shrink:!0,children:[(0,t.jsxs)("div",{clsx:Z.default.itemText,children:[l?(0,t.jsx)(U.default,{...(0,K.userLinkProps)(l),clsx:Z.default.usernameLink,children:l.username}):null," ",a,s?(0,t.jsx)(t.Fragment,{children:` ${s.team.displayName}. Click here to join`}):null,c?(0,t.jsx)(t.Fragment,{children:` the ${c.organization.name} workspace. Click here to join`}):null]}),(0,t.jsx)(J.Text,{variant:"small",color:"dimmer",multiline:!1,children:(0,t.jsx)(Q.Timestamp,{date:r})})]})]})})},et=({notification:e,isLastItem:i,setAsSeen:n,...o})=>{if("ReplCommentCreatedNotification"===e.__typename||"ReplCommentReplyCreatedNotification"===e.__typename||"ReplCommentMentionNotification"===e.__typename){let a={ReplCommentCreatedNotification:"commented on your repl",ReplCommentReplyCreatedNotification:"replied to your comment on your repl",ReplCommentMentionNotification:"mentioned you in your repl"}[e.__typename];return(0,t.jsx)(ee,{isLastItem:i,text:a||void 0,seen:n||e.seen,compact:o.compact,timeCreated:e.timeCreated,creator:e.creator||void 0})}if("BasicNotification"===e.__typename)return(0,t.jsx)(ee,{isLastItem:i,text:e.text||void 0,seen:n||e.seen,compact:o.compact,timeCreated:e.timeCreated,url:e.url});if("MentionedInPostNotification"===e.__typename)return(0,t.jsx)(ee,{isLastItem:i,text:"mentioned you in their post",creator:e.creator||void 0,seen:n||e.seen,compact:o.compact,timeCreated:e.timeCreated,url:e.url});if("MentionedInCommentNotification"===e.__typename)return(0,t.jsx)(ee,{isLastItem:i,text:"mentioned you in their comment",creator:e.creator||void 0,seen:n||e.seen,compact:o.compact,timeCreated:e.timeCreated,url:e.url});if("RepliedToPostNotification"===e.__typename)return(0,t.jsx)(ee,{isLastItem:i,text:"replied to your post",creator:e.creator||void 0,seen:n||e.seen,compact:o.compact,timeCreated:e.timeCreated,url:e.url});if("RepliedToCommentNotification"===e.__typename)return(0,t.jsx)(ee,{isLastItem:i,text:"replied to your comment",creator:e.creator||void 0,seen:n||e.seen,compact:o.compact,timeCreated:e.timeCreated,url:e.url});if("AnswerAcceptedNotification"===e.__typename)return(0,t.jsx)(ee,{isLastItem:i,text:"accepted your answer (you earned 5 cycles!)",creator:e.creator||void 0,seen:n||e.seen,compact:o.compact,timeCreated:e.timeCreated,url:e.url});if("WarningNotification"===e.__typename)return(0,t.jsx)(ee,{isLastItem:i,text:"You have been warned by a moderator.  Click here to learn more.",seen:n||e.seen,compact:o.compact,timeCreated:e.timeCreated,url:e.url});if("TeamInviteNotification"===e.__typename)return(0,t.jsx)(ee,{isLastItem:i,text:"You have been invited to join",invite:e.invite||void 0,seen:n||e.seen,compact:o.compact,timeCreated:e.timeCreated,url:e.url});if("TeamOrganizationInviteNotification"===e.__typename)return(0,t.jsx)(ee,{isLastItem:i,text:"You have been invited to join",orgInvite:e.invite||void 0,seen:n||e.seen,compact:o.compact,timeCreated:e.timeCreated,url:e.url});if("MultiplayerJoinedEmailNotification"===e.__typename||"MultiplayerJoinedLinkNotification"===e.__typename||"MultiplayerInvitedNotification"===e.__typename||"MultiplayerOverlimitNotification"===e.__typename)return(0,t.jsx)(ee,{isLastItem:i,text:e.text?e.text.split(" ").slice(1).join(" "):"",creator:e.creator||void 0,seen:n||e.seen,compact:o.compact,timeCreated:e.timeCreated,url:e.url});if("TeamTemplateSubmittedNotification"===e.__typename||"TeamTemplateReviewedStatusNotification"===e.__typename)return(0,t.jsx)(ee,{isLastItem:i,text:e.text,seen:n||e.seen,compact:o.compact,timeCreated:e.timeCreated,url:e.repl?.url||e.url});if("NewFollowerNotification"===e.__typename){let a=e.creator?(0,K.userLinkProps)(e.creator):null;return(0,t.jsx)(H,{seen:n||e.seen,compact:o.compact,as:a?.as,href:a?.href,isLastItem:i,children:(0,t.jsxs)("div",{clsx:Z.default.contentContainer,children:[(0,t.jsx)(Y.Avatar,{size:32,src:e.creator?.image??null,username:e.creator?.username??"",fullName:e.creator?.fullName}),(0,t.jsx)("div",{clsx:Z.default.content,children:(0,t.jsx)("div",{clsx:Z.default.itemTextNewFollowerWrapper,children:(0,t.jsxs)("div",{clsx:Z.default.itemText,children:[(0,t.jsxs)("div",{children:[e.creator?(0,t.jsx)(U.default,{...(0,K.userLinkProps)(e.creator),children:e.creator.username}):"[deleted]"," started following you"]}),(0,t.jsx)(J.Text,{variant:"small",color:"dimmer",multiline:!1,children:(0,t.jsx)(Q.Timestamp,{date:e.timeCreated})})]})})})]})})}return"OrgUpgradeRequestReviewedNotification"===e.__typename?(0,t.jsx)(ee,{creator:e.creator||void 0,isLastItem:i,text:e.isAccepted?"approved your request to join the workspace":"rejected your request to join the workspace",seen:n||e.seen,compact:o.compact,timeCreated:e.timeCreated,url:e.url}):"EgressLimitNotification"===e.__typename?(0,t.jsx)(ee,{creator:void 0,isLastItem:i,text:"egress_reached_limit"===e.variant?"You have reached your data transfer limit for the month. Your Apps' data transfer is being throttled, and will be shut off. Upgrade your plan or purchase additional data transfer with Cycles to resume normal speeds.":`You have used ${e.percentage}% of your monthly data transfer limit. If you reach the limit, your Apps data transfer will be throttled and eventually shut off. Upgrade your plan or purchase additional data transfer with Cycles to prevent disruptions to your Apps.`,seen:n||e.seen,compact:o.compact,timeCreated:e.timeCreated,url:e.url}):null},ei={},en=n.gql`
    mutation MarkNotificationsAsSeen($ids: [Int!]) {
  markNotificationsAsSeen(ids: $ids)
}
    `;var eo=e.i(980224);let ea=e=>{var t;let n,[o,a]=(0,i.useState)([]),{count:r,setUnreadCount:l}=(0,eo.default)(),s=e.notificationIds.filter(e=>-1===o.indexOf(e)),[c,{data:u}]=(t={variables:{ids:s}},n={...ei,...t},L.useMutation(en,n));return(0,i.useEffect)(()=>{0!==s.length&&(a([...o,...s]),c())},[s,c]),(0,i.useEffect)(()=>{u?.markNotificationsAsSeen&&l(Math.max(0,r-u.markNotificationsAsSeen))},[u,l]),null};var er=e.i(766299),el=e.i(643484),es=e.i(449525),ec=e.i(413325);e.s(["default",0,e=>{var n,o;let a,r,[l,s]=(0,i.useState)(!0),{count:c}=(0,eo.default)(),[u,d]=(0,i.useState)(!1),{data:m,loading:f,fetchMore:p}=(n={fetchPolicy:"cache-and-network",ssr:!1,notifyOnNetworkStatusChange:!0,variables:{...e.count?{count:e.count}:{},...l?{seen:!1}:{}}},a={...T,...n},S.useQuery(M,a)),x=(m?.notifications?.items??[]).filter(e=>"AnnotationNotification"!==e.__typename&&"ThreadNotification"!==e.__typename),[h]=(o={onCompleted(){d(!1)},optimisticResponse:{__typename:"RootMutationType",markAllNotificationsAsSeen:{__typename:"CurrentUser",id:m?.currentUser?.id,notificationCount:0}}},r={...A,...o},L.useMutation($,r)),g=(0,er.useIdSeed)();return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)(X.View,{row:!0,gap:16,justify:"space-between",clsx:[ec.default.list,{[ec.default.compact]:e.compact}],children:[(0,t.jsx)("div",{clsx:[ec.default.buttonGroupContainer,{[ec.default.compact]:e.compact&&c>0}],children:(0,t.jsxs)(es.ButtonGroup,{name:g("visibility"),value:l.toString(),primary:!0,onChange:()=>s(!l),row:!0,stretch:!0,children:[(0,t.jsx)(es.ButtonGroupItem,{id:g("true"),value:"true",text:"Unread"}),(0,t.jsx)(es.ButtonGroupItem,{id:g("false"),value:"false",text:"All"})]})}),c>0&&(0,t.jsx)(el.Button,{text:u?"Marking all...":"Mark as read",disabled:f,iconLeft:(0,t.jsx)(O.default,{}),stretch:!0,onClick:()=>{d(!0),h()}})]}),(0,t.jsxs)(X.View,{children:[!f||m&&m.notifications?null:(0,t.jsx)(X.View,{p:64,align:"center",children:(0,t.jsx)(P.default,{})}),0===x.length&&(0,t.jsx)("div",{clsx:[ec.default.emptyStateContainer,{[ec.default.compact]:e.compact}],children:(0,t.jsx)(X.View,{clsx:[ec.default.emptyState,{[ec.default.compact]:e.compact}],children:(0,t.jsx)(J.Text,{variant:"text",color:"dimmer",multiline:!1,clsx:ec.default.textCenter,children:l?"You're all caught up!":"No notifications"})})}),x.length?(0,t.jsxs)(t.Fragment,{children:[x.map((i,n)=>(0,t.jsx)(et,{compact:e.compact,notification:i,isLastItem:n===x.length-1,setAsSeen:!0},i.id)),e.markAsSeen&&(0,t.jsx)(ea,{notificationIds:x.filter(e=>"seen"in e&&!e.seen).map(e=>e.id)})]}):null,e.loadMore&&m?.notifications.pageInfo.nextCursor?(0,t.jsx)("div",{clsx:[ec.default.loadMoreContainer,{[ec.default.compact]:e.compact}],children:(0,t.jsx)(el.Button,{text:f?"Loading...":"Load more",onClick:()=>{f||p({variables:{after:m&&m.notifications&&!l?m.notifications.pageInfo.nextCursor:null},updateQuery:(e,t)=>{if(!t||!t.fetchMoreResult)return e;let{fetchMoreResult:i}=t,n=e?e.notifications.items:[],o={...i};return o.notifications.items=[...n,...i.notifications.items],o}})},disabled:f})}):null]})]})}],286093);var eu=e.i(55547),ed=e.i(908796),em=e.i(712903),ef=e.i(255701),ep=e.i(195206),ex=e.i(334028),eh=e.i(177037),eg=e.i(596139),eN=e.i(294827),ej=e.i(776065),ey=e.i(926233),ev=e.i(983420),eC=e.i(295231);function eI({right:e,label:i,...n}){return(0,t.jsxs)(eC.BaseMenuItem,{textValue:i,...n,children:[(0,t.jsxs)(X.View,{gap:6,pl:2,row:!0,align:"center",grow:!0,shrink:!0,children:[(0,t.jsx)(ev.IconProvider,{size:16,children:n.icon}),(0,t.jsx)(eC.MenuItemLabel,{children:i})]}),e??null]})}e.s(["MenuItemWithRightContent",0,eI],765185);var e_=e.i(648880),ew=e.i(919073),eb=e.i(638046);function ek({count:e,onAction:i}){return(0,t.jsx)(eC.BaseMenuItem,{textValue:"Notifications",onAction:i,children:(0,t.jsxs)(X.View,{align:"center",row:!0,gap:6,justify:"space-between",grow:!0,shrink:!0,children:[(0,t.jsxs)(X.View,{align:"center",grow:!0,shrink:!0,row:!0,gap:6,children:[(0,t.jsx)(e_.default,{}),(0,t.jsx)(J.Text,{children:"Notifications"})]}),e?(0,t.jsx)(ew.ShadesSurface,{clsx:eb.default.count,colorShade:"themeError",align:"center",justify:"center",children:(0,t.jsx)(J.Text,{variant:"small",children:e})}):null]})})}e.s(["AccountItems",0,function({currentUser:e,setActiveModal:i,notificationCount:n,isUnifiedPlanEnabled:o,onClose:a}){let r=(0,eu.useRouter)(),l=(0,K.userLinkProps)(e),{shouldHidePersonalWorkspace:s}=(0,eN.usePersonalWorkspacesDisabled)();return(0,t.jsxs)(t.Fragment,{children:[o?(0,t.jsx)(eC.MenuItem,{label:"Settings",icon:(0,t.jsx)(ef.default,{}),onAction:()=>{(0,ej.updatePathWithQueryParams)({router:r,params:[{mode:"add",key:ey.SETTINGS_SHOW_PARAM,value:"true"}]}),a?.()}}):(0,t.jsx)(eI,{label:"Account",as:"/account",href:"/account",dataCy:"avatar-dropdown-account-link",icon:e.isMemberOfAnyOrg?(0,t.jsx)(ef.default,{}):(0,t.jsx)(Y.Avatar,{size:16,src:e.image,username:e.username,fullName:e.fullName}),right:e.userSubscriptionType===ed.UserSubscriptionTypeEnum.HackerPro?(0,t.jsxs)(X.View,{row:!0,align:"center",gap:4,children:[(0,t.jsx)(em.default,{size:12,color:eh.brandOrange}),(0,t.jsx)(J.Text,{variant:"small",color:"dimmer",translate:"no",children:eg.corePlanName})]}):null}),s||o?null:(0,t.jsx)(eC.MenuItem,{label:"Profile",as:l.as,href:l.href,dataCy:"avatar-dropdown-account-link",icon:(0,t.jsx)(ex.default,{})}),(0,t.jsx)(ek,{count:n,onAction:()=>{i("notifications")}}),(0,t.jsx)(eC.Separator,{}),(0,t.jsx)(eC.MenuItem,{label:"CLUI",as:"/~/cli",href:"/~/cli",icon:(0,t.jsx)(ep.default,{})}),(0,t.jsx)(eC.Separator,{})]})}],736372),e.i(183940);var eS=e.i(320216);e.s(["DevCopyUsernameItem",0,function({currentUser:e}){let{showConfirm:i}=(0,eS.default)();return(0,t.jsx)(t.Fragment,{children:null})}],556278);var eT=e.i(625251),eR=e.i(787527),eM=e.i(399245),eL=e.i(222878),eA=e.i(735362),e$=e.i(761201),eO=e.i(519979);function eP(){return(0,t.jsx)(eC.MenuItem,{icon:(0,t.jsx)(eO.default,{}),label:"Status",href:"https://status.replit.com"})}var eU=e.i(773222);e.s(["HelpItem",0,function({setActiveModal:e,children:i}){return(0,t.jsx)(t.Fragment,{children:(0,t.jsxs)(eT.SubmenuTrigger,{children:[(0,t.jsx)(eC.BaseMenuItem,{textValue:"Help",children:(0,t.jsxs)(X.View,{align:"center",row:!0,gap:6,justify:"space-between",grow:!0,shrink:!0,children:[(0,t.jsxs)(X.View,{align:"center",grow:!0,shrink:!0,row:!0,gap:6,children:[(0,t.jsx)(eL.default,{}),(0,t.jsx)(J.Text,{children:"Help"})]}),(0,t.jsx)(q.default,{size:12})]})}),(0,t.jsx)(eU.RawPopover,{offset:4,children:(0,t.jsx)(X.View,{p:4,children:(0,t.jsxs)(eC.Menu,{"aria-label":"Help",children:[(0,t.jsx)(eP,{}),(0,t.jsx)(eC.MenuItem,{label:"Get help",icon:(0,t.jsx)(eL.default,{size:16}),onAction:()=>{e("support"),(0,B.track)(F.events.HELP_FORM_OPENED,{type:"New Help Form"})}}),(0,t.jsx)(eC.MenuItem,{icon:(0,t.jsx)(eM.default,{}),label:"Community Hub",href:e$.COMMUNITY_URL}),(0,t.jsx)(eC.MenuItem,{icon:(0,t.jsx)(eA.default,{}),label:"View updates",href:e$.LINKS_DOCS.CHANGELOG,onAction:()=>{(0,B.track)(F.events.CHANGELOG_OPENED)}}),(0,t.jsx)(eC.MenuItem,{icon:(0,t.jsx)(eR.default,{}),label:"Read the docs",href:e$.LINKS_DOCS.HOME,onAction:()=>{(0,B.track)(F.events.DOCS_OPENED,{source:"help_menu"})}}),i]})})})]})})}],566032)},70219,e=>{"use strict";var t=e.i(276385),i=e.i(408116),n=e.i(98346),o=e.i(443197),a=e.i(295231);e.s(["LogoutItem",0,function(){let e=(0,i.useApolloClient)();return(0,t.jsx)(a.MenuItem,{label:"Log out",icon:(0,t.jsx)(n.default,{}),onAction:async()=>{await (0,o.signOut)(e),window.location.href="/logout"}})}])},246613,e=>{"use strict";var t=e.i(276385),i=e.i(55547),n=e.i(625251),o=e.i(908796),a=e.i(183035),r=e.i(151027),l=e.i(320216),s=e.i(648552),c=e.i(294827),u=e.i(448942),d=e.i(276887),m=e.i(765185),f=e.i(825419),p=e.i(295231),x=e.i(8047),h=e.i(61732);e.s(["TeamsItem",0,function({currentUser:e}){let g=(0,r.useCurrentUserStoredOrgContext)(),{loading:N}=g,j=(0,s.useOrgSwitcher)(),{shouldHidePersonalWorkspace:y}=(0,c.usePersonalWorkspacesDisabled)(),v="CurrentUserOrganizationConnection"===e.orgs.__typename?e.orgs.items:null,{showError:C}=(0,l.default)(),I=(0,i.useRouter)();return!v?.length||N?null:(0,t.jsxs)(n.MenuSection,{children:[(0,t.jsx)(p.MenuHeader,{text:"Switch Workspace"}),y?null:(0,t.jsx)(m.MenuItemWithRightContent,{icon:(0,t.jsx)(f.Avatar,{size:16,src:e.image,username:e.username,fullName:e.fullName}),label:"Personal",onAction:()=>{j({type:o.OrgType.Personal}),I.push("/home","/~",{shallow:!1})},right:void 0===g.orgId?(0,t.jsx)(a.default,{}):void 0,selected:void 0===g.orgId}),v.map(({org:e,type:i})=>(0,t.jsxs)(p.BaseMenuItem,{textValue:e.name,onAction:()=>(e=>{if(!e.currentUserRole)return void C("Something went wrong, please try again.");j({type:o.OrgType.Team,id:e.id,slug:e.slug,orgRole:e.currentUserRole,orgDealContext:e.dealContext});let{home:t}=(0,u.orgLinks)({slug:e.slug});I.push(t.href,t.as)})(e),children:[(0,t.jsxs)(h.View,{grow:!0,shrink:!0,row:!0,gap:6,align:"center",children:[(0,t.jsx)(f.Avatar,{size:16,src:e.image??null,username:e.name,fullName:e.name}),(0,t.jsx)(x.Text,{translate:"no",children:e.name}),i?(0,t.jsx)(x.Text,{variant:"small",color:"dimmest",children:(0,d.orgGroupToDisplayName)(i)}):null]}),e.id===g.orgId?(0,t.jsx)(a.default,{}):null]},e.id)),(0,t.jsx)(p.Separator,{})]})}])},13465,e=>{"use strict";var t=e.i(276385),i=e.i(625251),n=e.i(927600),o=e.i(155119),a=e.i(759317),r=e.i(393428),l=e.i(308521),s=e.i(401036),c=e.i(841114),u=e.i(295231),d=e.i(773222),m=e.i(8047),f=e.i(61732);e.s(["ThemeItem",0,function(){let{currentTheme:e}=(0,s.useTheme)(),{setActiveTheme:p,isSystemTheme:x}=(0,c.useThemePreference)(),h="Custom";return x?h="System":"replitDark"===e.id?h="Dark":"replitLight"===e.id&&(h="Light"),(0,t.jsxs)(i.SubmenuTrigger,{children:[(0,t.jsx)(u.BaseMenuItem,{textValue:"Theme",children:(0,t.jsxs)(f.View,{align:"center",row:!0,gap:6,justify:"space-between",grow:!0,shrink:!0,children:[(0,t.jsxs)(f.View,{align:"center",grow:!0,shrink:!0,row:!0,gap:6,children:[(0,t.jsx)(r.default,{}),(0,t.jsx)(m.Text,{multiline:!1,children:"Theme"})]}),(0,t.jsxs)(f.View,{row:!0,gap:4,align:"center",children:[(0,t.jsx)(m.Text,{color:"dimmer",children:h}),(0,t.jsx)(n.default,{size:12})]})]})}),(0,t.jsx)(d.RawPopover,{offset:4,children:(0,t.jsx)(f.View,{p:4,children:(0,t.jsxs)(u.Menu,{"aria-label":"Theme",children:[(0,t.jsx)(u.MenuItem,{label:"Light",icon:(0,t.jsx)(l.default,{size:16}),onAction:()=>p("replitLight")}),(0,t.jsx)(u.MenuItem,{label:"Dark",icon:(0,t.jsx)(a.default,{size:16}),onAction:()=>p("replitDark")}),(0,t.jsx)(u.MenuItem,{label:"System",icon:(0,t.jsx)(o.default,{size:16}),onAction:()=>p("system")})]})})})]})}])}]);

//# debugId=a58e0c8a-987b-f156-c6e7-1884aa0550e6
//# sourceMappingURL=0v3bd2eqsob1..js.map